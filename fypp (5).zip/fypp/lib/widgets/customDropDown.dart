import 'package:flutter/material.dart';

import '../utils/CustomTextStyles.dart';
import '../utils/appColors.dart';

class CustomDropDown extends StatefulWidget {
  final List<String> items;
  final String hint;
  String? initialValue;
  final Function(String?) onChangedValue;
  Color? fillColor;
  Color? borderColor;
  TextStyle? hintStyle;
  TextStyle? textStyle;
  String? Icon;
  double? radius;
  Widget? prefixIcon;
  EdgeInsets? padding;
  double? width;
  bool? isNoIcon;
  bool? isReadOnly;
  double? textWidth;
  TextDirection? textDirection;

  CustomDropDown({
    Key? key,
    required this.hint,
    required this.items,
    required this.onChangedValue,
    this.fillColor,
    this.isReadOnly,
    this.borderColor,
    this.hintStyle,
    this.textStyle,
    this.Icon,
    this.radius,
    this.isNoIcon,
    this.textWidth,
    this.textDirection,
    this.initialValue,
    this.prefixIcon,
    this.padding,
    this.width,
  }) : super(key: key);

  @override
  State<CustomDropDown> createState() => _CustomDropDownState();
}

class _CustomDropDownState extends State<CustomDropDown> {
  String? dropdownValue;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      setState(() {
        if (widget.initialValue != null &&
            widget.items.contains(widget.initialValue)) {
          dropdownValue = widget.initialValue;
        }
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: widget.padding ??
          const EdgeInsets.only(left: 26, right: 26, top: 3, bottom: 3),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(widget.radius ?? 40.0),
        color: widget.fillColor ?? AppColors.d9d9d9,
      ),
      child: Directionality(
        textDirection: widget.textDirection ?? TextDirection.ltr,
        child: DropdownButtonHideUnderline(
          child: DropdownButton<String>(
            iconSize: 1,
            borderRadius: BorderRadius.circular(12),
            dropdownColor: AppColors.whiteColor,
            value: dropdownValue,
            hint: Container(
              width: widget.textWidth,
              child: Text(
                widget.hint,
                overflow: TextOverflow.ellipsis,
                maxLines: 2,
                textAlign: widget.textDirection != null
                    ? TextAlign.end
                    : TextAlign.start,
                style: widget.hintStyle ?? CustomTextStyles.l16_blac,
              ),
            ),
            items: widget.items.map((String item) {
              return DropdownMenuItem<String>(
                value: item,
                child: Text(item,
                    style: widget.textStyle ?? CustomTextStyles.l16_blac),
              );
            }).toList(),
            onChanged: widget.isReadOnly == true
                ? null
                : (String? newValue) {
                    setState(() {
                      dropdownValue = newValue;
                    });
                    widget.onChangedValue(newValue);
                  },
          ),
        ),
      ),
    );
  }
}
