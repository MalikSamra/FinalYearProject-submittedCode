import 'package:flutter/material.dart';

import '../utils/CustomTextStyles.dart';
import '../utils/appColors.dart';

class CompletePercentageContainer extends StatelessWidget {
  double? widthh;
  double? heightt;
  double? width1;
  String? text;


  CompletePercentageContainer({
    this.widthh,
    this.text,
    this.heightt,
    this.width1,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Padding(
      padding: const EdgeInsets.only(top: 20),
      child: Stack(
        children: <Widget>[
          Container(
            decoration: BoxDecoration(
                color: AppColors.whiteColor,
                border: Border.all(color: AppColors.primaryColor),
                borderRadius: BorderRadius.circular(35)),
            width: widthh ?? width * 0.08,
            height: heightt ?? height * 0.03,
          ),
          Container(
            decoration: BoxDecoration(
                color: AppColors.primaryColor,
                borderRadius: BorderRadius.circular(35)),
            width: width1 ?? width * 0.06,
            height: height * 0.03,
            child: Center(
              child: Text(
                text ?? '',
                style: CustomTextStyles.l17_white,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
