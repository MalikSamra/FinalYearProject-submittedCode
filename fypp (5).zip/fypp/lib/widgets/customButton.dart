// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';

import '../utils/appColors.dart';

class CustomButton extends StatefulWidget {
  double? height;
  double? width;
  double? radius;
  Color? color;
  final String? text;
  Function? onPressed;
  final TextStyle? textStyle;
  double? borderRadius;

  CustomButton(
      {Key? key,
      this.text,
      this.textStyle,
      this.height,
      this.borderRadius,
      this.color,
      this.width,
      this.radius,
      this.onPressed})
      : super(key: key);

  @override
  State<CustomButton> createState() => _CustomButtonState();
}

class _CustomButtonState extends State<CustomButton> {
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        if (widget.onPressed != null) {
          widget.onPressed!();
        }
      },
      child: Container(
        width: widget.width ?? double.infinity,
        height: widget.height,
        decoration: BoxDecoration(
            color: widget.color,
            border: Border.all(color: AppColors.primaryColor),
            borderRadius: BorderRadius.circular(widget.borderRadius ?? 12)),
        child: Center(child: Text(widget.text!, style: widget.textStyle)),
      ),
    );
  }
}
