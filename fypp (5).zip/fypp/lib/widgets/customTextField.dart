import 'package:flutter/material.dart';
import 'package:fypp/utils/appColors.dart';

import '../utils/CustomTextStyles.dart';

class RoundedTextField extends StatelessWidget {
  final String? hintText;
  final TextEditingController? textEditingController;
  bool isActive = true;
  double? width;
  Function(String?)? onChanged;

  RoundedTextField({
    super.key,
    this.width,
    this.textEditingController,
    this.hintText,
    this.onChanged,
    this.isActive = true,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width ?? 0,
      child: TextField(
        enabled: isActive,
        controller: textEditingController,
        onChanged: (String? value) {
          if (onChanged != null) {
            onChanged!(value);
          }
        },
        style: CustomTextStyles.l17_white.copyWith(color: Colors.black),
        decoration: InputDecoration(
          // hintStyle: CustomTextStyles.hiTextstyle,
          contentPadding: const EdgeInsets.only(left: 18, right: 5),
          filled: true,
          fillColor: Colors.white,
          hintText: hintText,
          hintStyle: CustomTextStyles.l24_black,
          border: const UnderlineInputBorder(
            borderSide:
                BorderSide(color: AppColors.primaryColor), // Border color
          ),
        ),
      ),
    );
  }
}
