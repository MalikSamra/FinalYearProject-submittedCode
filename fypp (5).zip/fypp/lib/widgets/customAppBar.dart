import 'package:flutter/material.dart';
import 'package:fypp/utils/appColors.dart';
import 'package:get/get.dart';

import '../utils/CustomTextStyles.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final Color? backgroundColor;
  final Color? textIconColor;
  final String? icon;
  final String? title;
  final double? height;
  final List<Widget>? menuItem;
  final bool hideBack;
  final Widget? leading;
  final Widget? trailing;
  double titleSpacing;

  CustomAppBar({
    super.key,
    this.leading,
    this.backgroundColor,
    this.textIconColor,
    this.icon,
    this.title = '',
    this.menuItem,
    this.height = kToolbarHeight,
    this.hideBack = false,
    this.trailing,
    required this.titleSpacing,
  });

  @override
  Size get preferredSize => Size.fromHeight(height!);

  @override
  Widget build(BuildContext context) {
    return AppBar(
        scrolledUnderElevation: 0.0,
        leading: Padding(
          padding: const EdgeInsets.only(top: 5, left: 10),
          child: InkWell(
            onTap: () {
              Get.back();
            },
            child: Icon(
              Icons.arrow_back,
              color: AppColors.whiteColor,
            ),
          ),
        ),
        leadingWidth: 40,
        automaticallyImplyLeading: false,
        titleSpacing: titleSpacing,
        toolbarHeight: preferredSize.height,
        iconTheme: IconThemeData(
          color: textIconColor,
        ),
        title: Padding(
          padding: const EdgeInsets.only(top: 5),
          child: Text(title!, style: CustomTextStyles.appBarTitleTextStyle),
        ),
        actions: [
          if (menuItem != null) ...menuItem!,
          if (trailing != null) trailing!,
        ],
        backgroundColor: AppColors.primaryColor);
  }
}
