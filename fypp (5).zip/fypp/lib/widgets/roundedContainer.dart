import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fypp/utils/CustomTextStyles.dart';

import '../utils/appColors.dart';

class RoundedContainerImage extends StatelessWidget {
  String? text;
  String? iText;
  double? widthh;
  String? name;

  RoundedContainerImage(
      {super.key, this.text, this.widthh, this.iText, this.name});

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Container(
      width: widthh ?? width * 0.15,
      decoration: BoxDecoration(
        color: AppColors.primaryColor,
        borderRadius: BorderRadius.circular(50),
      ),
      child: Padding(
        padding:
            const EdgeInsets.only(top: 10, bottom: 10, left: 12, right: 12),
        child: Expanded(
          child: Text(
            text! + ' ' + name!,
            style: CustomTextStyles.l24_white,
          ),
        ),

      ),
    );
  }
}
