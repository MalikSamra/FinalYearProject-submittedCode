import 'package:flutter/material.dart';
import 'package:fypp/utils/CustomTextStyles.dart';

import '../utils/appColors.dart';

class CustomContainerRounded extends StatelessWidget {
  String? text;
  Color? color;
  Color? textColor;

  CustomContainerRounded({super.key, this.text, this.color, this.textColor});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: color ?? AppColors.d9d9d9,
        borderRadius: BorderRadius.circular(50),
      ),
      child: Padding(
        padding:
            const EdgeInsets.only(top: 10, bottom: 10, left: 35, right: 35),
        child: Center(
          child: Text(
            text!,
            style: CustomTextStyles.l24_black,
          ),
        ),
      ),
    );
  }
}
