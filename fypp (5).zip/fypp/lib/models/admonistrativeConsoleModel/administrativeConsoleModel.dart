class CourseInformation {
  String? className;
  String? courseName;
  String? courseNo;
  String? credit;
  String? teacherName;
  String? teacherId;

  CourseInformation({
    this.className,
    this.courseName,
    this.courseNo,
    this.credit,
    this.teacherName,
    this.teacherId,
  });
}
