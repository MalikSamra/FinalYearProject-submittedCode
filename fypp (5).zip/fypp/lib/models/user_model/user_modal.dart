class UserModal{
  String username;
  String email;
  String userType;
  String uid ;

  UserModal({required this.username, required this.email, required this.userType, required this.uid});

  factory UserModal.fromJson(Map<String, dynamic> json) {
    return UserModal(
      username: json['username'],
      email: json['email'],
      userType: json['userType'],
      uid: json['uid'],
    );
  }
}