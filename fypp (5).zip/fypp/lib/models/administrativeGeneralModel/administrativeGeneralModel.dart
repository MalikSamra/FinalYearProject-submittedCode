// To parse this JSON data, do
//
//     final newsModel = newsModelFromJson(jsonString);

import 'dart:convert';

List<AdministrationGeneralModel> administrationGeneralModelFromJson(String str) =>
    List<AdministrationGeneralModel>.from(
        json.decode(str).map((x) => AdministrationGeneralModel.fromJson(x)));

String administrationGeneralModelToJson(List<AdministrationGeneralModel> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class AdministrationGeneralModel {
  String? code;
  String? subject;
  String? subjectCode;
  String? creditHours;
  String? teacherName;
  String? sCode;

  AdministrationGeneralModel({
    this.subject,
    this.code,
    this.subjectCode,
    this.creditHours,
    this.teacherName,
    this.sCode,
  });

  factory AdministrationGeneralModel.fromJson(Map<String, dynamic> json) =>
      AdministrationGeneralModel(
        subject: json["subject"],
        code: json["code"],
        subjectCode: json["subjectCode"],
        creditHours: json["creditHours"],
        teacherName: json["teacherName"],
        sCode: json["sCode"],
      );

  Map<String, dynamic> toJson() => {
        "code": code,
        "subject": subject,
        "subjectCode": subjectCode,
        "creditHours": creditHours,
        "teacherName": teacherName,
        "sCode": sCode,
      };
}
