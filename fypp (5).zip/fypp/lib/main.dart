// main.dart
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fypp/controllers/user_controller.dart';
import 'package:fypp/models/user_model/user_modal.dart';
import 'package:fypp/utils/constants.dart';
import 'package:fypp/views/administrativeConsole/administrativeConsole.dart';
import 'package:fypp/views/facultyMemberConsole/facultyMemberConsole.dart';
import 'package:fypp/views/qecConverConsole/qecConverConsole.dart';
import 'package:fypp/views/qecMemberConsole/qecMemberConsole.dart';
import 'package:fypp/views/selectionScreen/selectionScreen.dart';
import 'package:get/get.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'firebase_options.dart';

void main() async {
  EasyLoading.instance
    ..indicatorType = EasyLoadingIndicatorType.spinningCircle
    ..loadingStyle = EasyLoadingStyle.light
    ..indicatorSize = 45.0
    ..radius = 10.0
    ..progressColor = Colors.deepPurple
    ..backgroundColor = Colors.white
    ..indicatorColor = Colors.deepPurple
    ..textColor = Colors.deepPurple
    ..userInteractions = false
    ..dismissOnTap = false;
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: Constants.EXPO_PUBLIC_SUPABASE_URL, // Replace with your Supabase URL
    anonKey: Constants.EXPO_PUBLIC_SUPABASE_ANON_KEY, // Replace with your Supabase Anon Key
  );
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  Get.put(UserController());
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool isLoading = true;
  UserModal? userModal;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    checkUser();

  }
  void navigateToConsole(String role) {
    switch (role) {
      case 'administrative':
        Get.to(() => AdministrativeConsole());
        break;
      case 'qecconver':
        Get.to(() => QecConverConsole());
        break;
      case 'qecmemberconsole':
        Get.to(() => QecMemberConsole());
        break;
      case 'facultymember':
        Get.to(() => FacultyMemberConsole());
        break;
      default:
        Get.to(() => FacultyMemberConsole()); // Default navigation
        break;
    }
  }

  void checkUser() {
    var userController = Get.find<UserController>();
    userController.checkUser();
    if(userController.userModal != null){
      setState(() {
        isLoading = false;
        userModal = userController.userModal;
      });

    }else{
      setState(() {
        isLoading = false;
      });
    }
  }
  @override
  Widget build(BuildContext context) {

    return ScreenUtilInit(
      designSize: const Size(1920, 1080),
      minTextAdapt: true,
      splitScreenMode: true,
      child: GetMaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Flutter Demo',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
          useMaterial3: true,
        ),
        home: isLoading ? Scaffold(
          body: Center(
            child: CircularProgressIndicator(),
          ),
        ) : userModal != null ? Builder(
          builder: (context) {
            navigateToConsole(userModal!.userType);
            return Container();
          },
        ) :  UserSelectionScreen(),
        builder: EasyLoading.init(),
      ),
    );
  }
}
