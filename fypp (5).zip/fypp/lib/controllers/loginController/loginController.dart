import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class LoginController extends GetxController {
  var keepLoggedIn = false.obs;
  var isCheckIcon = true.obs;
  var invisible = true.obs;
  RxBool showPassword = true.obs;
  RxBool isLoggedIn = false.obs;

  final TextEditingController usernameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController =
      TextEditingController();

  var username = ''.obs; // Reactive variable for username

  void updateKeepLoggedIn(bool value) {
    keepLoggedIn.value = value;
  }

  void toggleIcon() {
    isCheckIcon.value = !isCheckIcon.value;
  }

  void toggleShowPassword() {
    showPassword.value = !showPassword.value;
  }

  Future<void> login() async {
    try {
      // Implement Firebase authentication login logic here
      UserCredential userCredential =
          await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: emailController.text.trim(),
        password: passwordController.text.trim(),
      );

      // Update the username for further usage
      username.value = usernameController.text;
      isLoggedIn.value = true;

      // Navigate to the console screen or show success message
      print("Logged in successfully");
    } catch (e) {
      // Handle errors, show error message
      print("Error logging in: $e");
      Get.snackbar("Login Error", e.toString());
    }
  }

  Future<void> signup() async {
    try {
      // Implement Firebase authentication signup logic here
      UserCredential userCredential =
          await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: emailController.text.trim(),
        password: passwordController.text.trim(),
      );

      // Update the username for further usage
      username.value = usernameController.text;
      isLoggedIn.value = true;

      // Navigate to the console screen or show success message
      print("Signed up successfully");
    } catch (e) {
      // Handle errors, show error message
      print("Error signing up: $e");
      Get.snackbar("Signup Error", e.toString());
    }
  }
}
