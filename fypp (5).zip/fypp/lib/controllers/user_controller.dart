

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fypp/models/user_model/user_modal.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

class UserController extends GetxController{
  UserModal? _userModal;
  Map<String, dynamic> _course = {};
  String _facultySelectedCourse = '';
  Map<String, dynamic> _facultyCourse= {};
  String selectFacId = '';

  UserModal? get userModal => _userModal;
  String get facultySelectedCourse => _facultySelectedCourse;
  Map<String, dynamic> get course => _course;
  Map<String, dynamic> get facultyCourse => _facultyCourse;
  String get selectedFacId => selectFacId;

  void setSelectFacId(String id){
    selectFacId = id;
    update();
  }

  void setFacultyCourse(Map<String, dynamic> course){
    _facultyCourse = course;
    update();
  }
  void emptyFacultyCourse(){
    _facultyCourse = {};
    update();
  }

  void setFacultySelectedCourse(String course){
    _facultySelectedCourse = course;
    update();
  }
  void emptyFacultySelectedCourse(){
    _facultySelectedCourse = '';
    update();
  }

  void setCourse(Map<String, dynamic> course){
    _course = course;
    update();
  }

  void emptyCourse(){
    _course = {};
    update();
  }

  void setUserModal(UserModal userModal){
    _userModal = userModal;
    update();
  }

  void checkUser()async{
    var prefs = await SharedPreferences.getInstance();
    var uid = prefs.getString('uid');
    if(uid != null){
      var userDoc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
      setUserModal(UserModal.fromJson({
        'email': userDoc['email'],
        'username': userDoc['username'],
        'userType': userDoc['userType'],
        'uid': uid,
      }));
    }else{

    }
    update();
  }

}