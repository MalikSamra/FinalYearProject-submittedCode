import 'package:flutter/material.dart';
import 'package:fypp/models/administrativeGeneralModel/administrativeGeneralModel.dart';

import '../../../assetsPath/assetsPath.dart';
import '../../../utils/appColors.dart';

class AdministrativeGeneralContainer extends StatelessWidget {
  final double height;
  final double width;
  AdministrationGeneralModel? administrationGeneralModel;

  AdministrativeGeneralContainer({
    super.key,
    this.administrationGeneralModel,
    required this.height,
    required this.width,
  });

  @override
  Widget build(BuildContext context) {
    print('code ${administrationGeneralModel?.code}');
    print('code ${administrationGeneralModel?.teacherName}');
    return Container(
      padding: EdgeInsets.only(top: 10, left: 14, right: 10, bottom: 10),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(35),
          border: Border.all(color: AppColors.primaryColor, width: 1)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(administrationGeneralModel?.code ?? ''),
          Text(administrationGeneralModel?.subject ?? ''),
          Text(administrationGeneralModel?.subjectCode ?? ''),
          Text(administrationGeneralModel?.creditHours ?? ''),
          Text(administrationGeneralModel?.teacherName ?? ''),
          Text(administrationGeneralModel?.sCode ?? ''),
          Image.asset(
            '${Assets.imagesPath}${Assets.crossIcon}',
            height: height * 0.025,
            width: width * 0.025,
          )
        ],
      ),
    );
  }
}
