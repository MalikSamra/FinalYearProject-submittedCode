// ignore_for_file: unused_import

import 'package:fypp/models/administrativeGeneralModel/administrativeGeneralModel.dart';
import 'package:get/get.dart';

import '../../assetsPath/assetsPath.dart';

class QecConsoleController extends GetxController {
  RxList<AdministrationGeneralModel> administrationGeneralModel =
      <AdministrationGeneralModel>[].obs;

  var selectClass = ''.obs;
  var selectCoarseName = ''.obs;
  var coarseNo = ''.obs;
  var credit = ''.obs;
  var qecMember = ''.obs;
  var qecMemberId = ''.obs;

  @override
  void onInit() {
    super.onInit();
    fetchData();
  }

  void saveValuesToModel() {
    AdministrationGeneralModel adminModel = AdministrationGeneralModel();

    adminModel.subject = selectCoarseName.value;
    adminModel.code = selectClass.value;
    adminModel.subjectCode = coarseNo.value;
    adminModel.creditHours = credit.value;
    adminModel.teacherName = qecMember.value;
    adminModel.sCode = qecMemberId.value;

    print(adminModel.toJson());

    List<AdministrationGeneralModel> administrationModels = [];
    administrationModels.add(adminModel);
  }

  void fetchData() {
    // Clear existing data
    administrationGeneralModel.clear();

    // Create an instance of AdministrationGeneralModel using the selected values from dropdowns
    AdministrationGeneralModel adminModel = AdministrationGeneralModel(
      teacherName: qecMember.value,
      subject: selectCoarseName.value,
      subjectCode: coarseNo.value,
      creditHours: credit.value,
      code: selectClass.value,
      sCode: qecMemberId.value,
    );

    // Add the created instance to the list
    administrationGeneralModel.add(adminModel);
  }
}
