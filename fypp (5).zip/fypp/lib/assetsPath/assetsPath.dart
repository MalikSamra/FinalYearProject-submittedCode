class Assets {
  static const String imagesPath = 'assets/images/';
  static const String iconsPath = 'assets/icons/';

  static const String logo = 'uniLogo.png';
  static const String crossIcon = 'crossIcon.png';
  static const String assmntPic = 'assmntPic.png';
  static const String active = 'active.png';
  static const String inActive = 'inActive.png';
  static const String greyImage = 'greyImage.png';
  static const String logo2Png = 'logo2Png.png';
  static const String Recaptcha = 'Recaptcha.png';
  static const String logoSvg = 'logoSvg.svg';
  static const String logo2 = 'logo2.svg';
  static const String logosSvg = 'assets/icons/logoSvg.svg';
}
