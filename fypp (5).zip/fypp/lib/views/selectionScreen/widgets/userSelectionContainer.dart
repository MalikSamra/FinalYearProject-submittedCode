import 'package:flutter/material.dart';
import 'package:fypp/utils/CustomTextStyles.dart';
import 'package:fypp/utils/appColors.dart';

class UserSelectionContainer extends StatelessWidget {
  String? text;
  VoidCallback? onTap;

  UserSelectionContainer({super.key, this.text, this.onTap});

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return InkWell(
      onTap: onTap,
      child: Container(
        height: height * 0.254,
        width: width * 0.216,
        decoration: BoxDecoration(
          color: AppColors.primaryColor,
          borderRadius: BorderRadius.circular(24),
        ),
        child: Padding(
          padding: EdgeInsets.only(
              // left: height * 0.06,
              // right: height * 0.06,
              // top: height * 0.07,
              // bottom: height * 0.07
              ),
          child: Center(
            child: Text(
              text ?? '',
              style: CustomTextStyles.l36_white,
              textAlign: TextAlign.center,
              maxLines: 2,
            ),
          ),
        ),
      ),
    );
  }
}
