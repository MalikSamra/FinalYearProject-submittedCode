import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fypp/utils/CustomTextStyles.dart';
import 'package:fypp/utils/appColors.dart';
import 'package:fypp/views/selectionScreen/widgets/userSelectionContainer.dart';
import 'package:get/get.dart';

import '../../assetsPath/assetsPath.dart';
import '../loginScreen/loginScreen.dart';

class UserSelectionScreen extends StatefulWidget {
  UserSelectionScreen({super.key});

  @override
  State<UserSelectionScreen> createState() => _UserSelectionScreenState();
}

class _UserSelectionScreenState extends State<UserSelectionScreen> {
  String text = '';

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    print('height $height');
    print('width $width');
    return Scaffold(
      body: Stack(
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Stack(
                children: [
                  Container(
                    padding: EdgeInsets.only(
                        top: height * 0.06, bottom: height * 0.1),
                    child: Container(
                      padding: EdgeInsets.only(
                          top: 35, bottom: 30, left: 70, right: 100),
                      color: AppColors.primaryColor,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            padding: EdgeInsets.only(left: width * 0.07),
                            width: 300.w,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'FACULTY COURSE FOLDERS MANAGEMENT SYSTEM',
                                style: CustomTextStyles.l28_400_white,
                                maxLines: 2,
                              ),
                              SizedBox(height: 10.h),
                              Container(
                                width: 300.w,
                                child: Text(
                                  '',
                                  style: CustomTextStyles.l24_white,
                                  maxLines: 2,
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    left: -1000,
                    right: 50,
                    top: 15,
                    child: Image.asset(
                      '${Assets.imagesPath}${Assets.logo}',
                      height: 250.h,
                      width: 250.w,
                    ),
                  )
                ],
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 62),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    UserSelectionContainer(
                      text: 'Administrative\nConsole',
                      onTap: () {
                        setState(() {
                          text = 'Administrative'.toLowerCase();
                        });
                        Get.to(LoginScreen(
                          text: text,
                        ));
                      },
                    ),
                    UserSelectionContainer(
                      onTap: () {
                        setState(() {
                          text = 'facultymember'.toLowerCase();
                        });
                        Get.to(LoginScreen(
                          text: text,
                        ));
                      },
                      text: 'Faculty\nConsole',
                    ),
                    UserSelectionContainer(
                      onTap: () {
                        setState(() {
                          text = 'qecConver'.toLowerCase();
                        });
                        Get.to(LoginScreen(
                          text: text,
                        ));
                      },
                      text: 'QEC Convenor\nConsole',
                    ),
                    UserSelectionContainer(
                      onTap: () {
                        setState(() {
                          text = 'qecmemberConsole'.toLowerCase();
                        });
                        Get.to(LoginScreen(
                          text: text,
                        ));
                      },
                      text: 'QEC Member\nConsole',
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 20),
                child: Text('Click on your console to Log-in'),
              )
            ],
          ),
        ],
      ),
    );
  }
}
