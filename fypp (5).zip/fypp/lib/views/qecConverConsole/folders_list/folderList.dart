import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class Folderlist extends StatefulWidget {
  const Folderlist({super.key});

  @override
  State<Folderlist> createState() => _FolderlistState();
}

class _FolderlistState extends State<Folderlist> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder(
        future: FirebaseFirestore.instance.collection("assignedCourses").get(),
        builder: (context, snaps) {
          if (snaps.connectionState == ConnectionState.waiting) {
            return Container();
          }
          if (snaps.hasError) {
            return Text('Error: ${snaps.error}');
          }
          return ListView.builder(
            itemCount: snaps.data!.docs.length,
            itemBuilder: (context, index) {
              var data = snaps.data!.docs[index];
              return Card(
                child: ListTile(
                  title: Text(data['courseCode']),
                  subtitle: Text(data['courseName']),
                ),
              );
            },
          );
        }
      )
    );
  }
}
