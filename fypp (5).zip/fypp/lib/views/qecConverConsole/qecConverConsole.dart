import 'package:flutter/material.dart';
import 'package:fypp/controllers/user_controller.dart';
import 'package:fypp/views/qecConverConsole/folders_list/folderList.dart';
import 'package:fypp/views/qecConverConsole/qecConvenorCommunicate/qecConverCommunicate.dart';
import 'package:fypp/views/qecConverConsole/qecConverHomeScreen/qecConverHomeScreen.dart';
import 'package:fypp/views/qecConverConsole/report/generate_report.dart';
import 'package:fypp/widgets/customAppBar.dart';
import 'package:fypp/widgets/roundedContainer.dart';
import 'package:get/get.dart';

import '../../utils/CustomTextStyles.dart';
import '../../utils/appColors.dart';
import 'qecGeneralScreen/qecGeneralScreen.dart';

class QecConverConsole extends StatefulWidget {
  const QecConverConsole({super.key});

  @override
  State<QecConverConsole> createState() => _QecConverConsoleState();
}

class _QecConverConsoleState extends State<QecConverConsole>
    with TickerProviderStateMixin {
  TabController? tabcontroller;
  int selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    tabcontroller = TabController(length: 5, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return GetBuilder<UserController>(
      builder: (controller) {
        return Scaffold(
          appBar: CustomAppBar(
            titleSpacing: 0.0,
            title: 'QEC Conver Console',
          ),
          body: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: EdgeInsets.only(top: 50, left: 30, bottom: 20),
                width: width * 0.25,
                color: AppColors.whiteColor,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildVerticalTab('Home', 0),
                    SizedBox(height: height * 0.01),
                    _buildVerticalTab('Communicate', 1),
                    SizedBox(height: height * 0.01),
                    _buildVerticalTab('General', 2),
                    SizedBox(height: height * 0.01),
                    _buildVerticalTab('Folder List', 3),
                    SizedBox(height: height * 0.01),
                    _buildVerticalTab('Report', 4),
                    Spacer(),
                    RoundedContainerImage(
                      text: 'Qec Conver',
                      name: controller.userModal!.username,
                      widthh: width * 0.17,
                    )
                  ],
                ),
              ),
              Expanded(
                child: TabBarView(
                  controller: tabcontroller,
                  children: [
                    QecConverHomeScreen(),
                    Qecconvercommunicate(),
                    QecGeneralScreen(),
                    Folderlist(),
                    GenerateReport(),
                  ],
                ),
              ),
            ],
          ),
        );
      }
    );
  }

  Widget _buildVerticalTab(String label, int index) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return InkWell(
      onTap: () {
        setState(() {
          selectedIndex = index;
        });
        tabcontroller!.animateTo(index);
      },
      child: Container(
        height: 42,
        width: width * 0.1,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(35),
            border: Border.all(
                color: selectedIndex == index
                    ? AppColors.primaryColor
                    : Colors.transparent,
                width: 3)),
        child: Center(
          child: Text(
            label,
            style: selectedIndex == index
                ? CustomTextStyles.l24_black
                : CustomTextStyles.l24_black,
          ),
        ),
      ),
    );
  }
}
