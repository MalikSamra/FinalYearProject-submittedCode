import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:fypp/assetsPath/assetsPath.dart';
import 'package:fypp/controllers/qecConsoleController/qecConsoleController.dart';
import 'package:fypp/utils/CustomTextStyles.dart';
import 'package:fypp/utils/appColors.dart';
import 'package:fypp/widgets/customButton.dart';
import 'package:get/get.dart';

import '../../../widgets/customDropDown.dart';

class QecConverHomeScreen extends StatefulWidget {
  const QecConverHomeScreen({super.key});

  @override
  State<QecConverHomeScreen> createState() => _QecConverHomeScreenState();
}

class _QecConverHomeScreenState extends State<QecConverHomeScreen> {
  QecConsoleController qecConsoleController = Get.put(QecConsoleController());
  String selectedCourse = '';
  String selectCourseFaculty = '';
  var selectCourseCode = '';
  String qecmemberid = '';

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;

        return Container(
          color: AppColors.lightBlue,
          padding: EdgeInsets.only(left: 20, right: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 18, right: 30),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    CustomButton(
                      height: height * 0.04,
                      width: width * 0.05,
                      text: 'Save',
                      onPressed: () async{
                        EasyLoading.show(status: 'Saving data...');
                        try {
                          if(qecConsoleController.selectCoarseName.value == '' || qecConsoleController.qecMember.value == '') {
                            EasyLoading.showError('Please fill all fields');
                            EasyLoading.dismiss();
                            return;
                          }
                          var ref = FirebaseFirestore.instance.collection(
                              "assignedCoursesQEC").doc();
                          await ref.set({
                            'courseName': qecConsoleController.selectCoarseName
                                .value,
                            'facultyId': selectCourseFaculty,
                            'qecMember': qecConsoleController.qecMember.value,
                            'id': ref.id,
                            'courseCode': selectCourseCode,
                            'qecMemberId': qecmemberid,
                            "last_updated": DateTime.now(),
                            "checked_files": [
                              ""
                            ],
                            'isSubmitted': false,
                          });
                          EasyLoading.showSuccess('Data saved successfully');
                          setState(() {
                            qecConsoleController.selectCoarseName.value = '';
                            qecConsoleController.qecMember.value = '';
                            selectedCourse = '';
                            selectCourseFaculty = '';
                            qecmemberid = '';
                          });
                          EasyLoading.dismiss();
                        } catch (e) {
                          EasyLoading.showError('Error: $e');
                          EasyLoading.dismiss();
                          print(e);
                        }
                      },
                      color: AppColors.primaryColor,
                      textStyle: CustomTextStyles.l26_white,
                      borderRadius: 40,
                    ),
                  ],
                ),
              ),
              SizedBox(height: height * 0.02),
              Text(
                'Select Assigned Course information:',
                style: CustomTextStyles.l24_black,
                textAlign: TextAlign.start,
                maxLines: 3,
              ),
              SizedBox(height: height * 0.03),
              FutureBuilder(
                  future: FirebaseFirestore.instance.collection("assignedCourses").get(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(
                        child: CircularProgressIndicator(),

                    );
                  }
                  if (snapshot.hasError) {
                    return Center(
                        child: Text('Error: ${snapshot.error}'),

                    );
                  }
                  return Container(
                    padding: EdgeInsets.only(top: 10, left: 14, right: 10, bottom: 10),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(35),
                        border: Border.all(color: AppColors.primaryColor, width: 1)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        /*CustomDropDown(
                            hint: 'Class',
                            items: [
                              "BSC",
                              "BCS",
                            ],
                            onChangedValue: (value) {
                              setState(() {
                                qecConsoleController.selectClass.value = value!;
                              });
                            },
                            width: width * 0.2,
                            initialValue: qecConsoleController.selectClass.value),*/
                        CustomDropDown(
                            hint: 'Course Name',
                            items: snapshot.data!.docs.map((e) => e['courseName'] as String ).toList(),
                            onChangedValue: (value) {
                              var course = snapshot.data!.docs.firstWhere((element) => element['courseName'] == value);
                              setState(() {
                                qecConsoleController.selectCoarseName.value = value!;
                                selectCourseFaculty = snapshot.data!.docs.firstWhere((element) => element['courseName'] == value)['facId'];
                                selectedCourse = "(${course['theoryCredits']}, ${course['labCredits']})";
                                selectCourseCode = course['courseCode'];
                              });
                            },
                            width: width * 0.2,
                            initialValue: qecConsoleController.selectCoarseName.value),
                        selectCourseFaculty == '' ? Container(
                          child: Text('Faculty: Not Selected',
                            style: CustomTextStyles.l24_black,
                            textAlign: TextAlign.start,
                            maxLines: 3,
                          ),
                        ) : FutureBuilder(
                          future: FirebaseFirestore.instance.collection("users").doc(selectCourseFaculty).get(),
                          builder: (context, snp) {
                            if (snp.connectionState == ConnectionState.waiting) {
                              return CircularProgressIndicator();
                            }
                            if (snp.hasError) {
                              return Text('Error: ${snp.error}');
                            }
                            return Text(
                              'Faculty: ${snp.data!['username']}',
                              style: CustomTextStyles.l24_black,
                              textAlign: TextAlign.start,
                              maxLines: 3,
                            );
                          }
                        ),
                    selectedCourse == '' ? Container() :  Text(
                                'Credit Hours: ${selectedCourse}',
                                style: CustomTextStyles.l24_black,
                                textAlign: TextAlign.start,
                                maxLines: 3,
                              ),

                        InkWell(
                          onTap: () {
                            setState(() {
                              qecConsoleController.selectCoarseName.value = '';
                              selectedCourse = '';
                              selectCourseFaculty = '';
                            });
                          },
                          child: Image.asset(
                            '${Assets.imagesPath}${Assets.crossIcon}',
                            height: height * 0.03,
                            width: width * 0.03,
                          ),
                        )
                      ],
                    ),
                  );
                }
              ),
              const SizedBox(height: 200),
              Text(
                'Assigned To',
                style: CustomTextStyles.l24_black,
                textAlign: TextAlign.start,
                maxLines: 3,
              ),
              SizedBox(height: height * 0.02),
              FutureBuilder(
                future: FirebaseFirestore.instance.collection("users").get(),
                builder: (context, snap) {
                  if (snap.connectionState == ConnectionState.waiting) {
                    return  Center(
                        child: CircularProgressIndicator(),

                    );
                  }
                  if (snap.hasError) {
                    return Center(
                        child: Text('Error: ${snap.error}'),

                    );
                  }
                  var mem = snap.data!.docs.where((user) => user['userType'].toString().contains("qecmemberconsole")).toList();
                  return Container(
                    padding: EdgeInsets.only(top: 10, left: 14, right: 10, bottom: 10),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(35),
                        border: Border.all(color: AppColors.primaryColor, width: 1)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CustomDropDown(
                            hint: 'Qec Member',
                            items: mem.map((e) => e['username'] as String ).toList(),
                            onChangedValue: (value) {
                              setState(() {
                                qecConsoleController.qecMember.value = value!;
                                qecmemberid = mem.firstWhere((element) => element['username'] == value)['uid'];
                              });
                            },
                            width: width * 0.2,
                            initialValue: qecConsoleController.qecMember.value),

                      ],
                    ),
                  );
                }
              ),

            ],
          ),
        );


  }
}
