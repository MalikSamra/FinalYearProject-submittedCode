import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:fypp/views/qecConverConsole/qecConvenorCommunicate/qecCommunicate.dart';

import '../../../utils/constants.dart';

class Qecconvercommunicate extends StatefulWidget {
  const Qecconvercommunicate({super.key});

  @override
  State<Qecconvercommunicate> createState() => _QecconvercommunicateState();
}

class _QecconvercommunicateState extends State<Qecconvercommunicate> {
  String selectedUserId = '';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: StreamBuilder(
          stream: FirebaseFirestore.instance.collection("users").snapshots(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(
                child: CircularProgressIndicator(),
              );
            }
            if (snapshot.hasError) {
              return Center(
                child: Text('Error: ${snapshot.error}'),
              );
            }
            var users = snapshot.data!.docs.where((element) => element['userType'] != 'qecconver').toList();
            users = users.where((element) => element['userType'] != 'facultymember').toList();

            return Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 200,
                  child: ListView.builder(itemCount: users.length, shrinkWrap: true, itemBuilder: (context, index) {
                    return Card(
                      child: ListTile(
                        onTap: (){
                          setState(() {
                            selectedUserId = users[index].id;
                          });
                        },
                        title: Text(users[index]['username']),
                        subtitle: Text(Constants.getAbb(users[index]['userType'])),
                      ),
                    );
                  },),
                ),
                Expanded(child: selectedUserId == '' ? Center(
                  child: Text('Select a member to communicate'),
                ) : Qeccommunicate(selectedUserId: selectedUserId))
              ],
            );
          }
      ),
    );
  }

}
