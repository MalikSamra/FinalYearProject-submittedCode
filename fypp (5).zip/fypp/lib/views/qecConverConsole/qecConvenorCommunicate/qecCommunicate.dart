import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../controllers/user_controller.dart';
import '../../../utils/appColors.dart';

class Qeccommunicate extends StatefulWidget {
  final String selectedUserId;
  const Qeccommunicate({super.key, required this.selectedUserId});

  @override
  State<Qeccommunicate> createState() => _QeccommunicateState();
}

class _QeccommunicateState extends State<Qeccommunicate> {
  final messageController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backGroundColor,
      body: GetBuilder<UserController>(
          builder: (controller) {
            return StreamBuilder(
                stream: FirebaseFirestore.instance.collection("chats").doc(
                    widget.selectedUserId + controller.userModal!.uid)
                    .collection("messages").orderBy(
                    "timestamp", descending: true)
                    .snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(
                      child: CircularProgressIndicator(),
                    );
                  }
                  if (snapshot.hasError) {
                    return Center(
                      child: Text('Error: ${snapshot.error}'),
                    );
                  }
                  print(snapshot.data!.docs.length);
                  return Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 50,
                        vertical: 10
                    ),
                    child: Column(
                      children: [
                        Expanded(
                            flex: 8, child: ListView.builder(itemCount: snapshot
                            .data!.docs.length,
                          reverse: true,
                          itemBuilder: (context, index) {
                            return snapshot.data!.docs[index]['sender'] ==
                                controller.userModal!.username
                                ? senderMessageBubble(
                                snapshot.data!.docs[index]['message'])
                                : receiverMessageBubble(
                                snapshot.data!.docs[index]['message']);
                          },)),
                        Expanded(child: Row(
                          children: [
                            Expanded(child: TextField(
                              controller: messageController,
                              decoration: InputDecoration(
                                hintText: 'Type a message',

                              ),
                            )),
                            IconButton(onPressed: () async {
                              await FirebaseFirestore.instance.collection(
                                  "chats").doc(widget.selectedUserId +
                                  controller.userModal!.uid).collection(
                                  "messages").add({
                                'message': messageController.text,
                                'sender': controller.userModal!.username,
                                'senderId': controller.userModal!.uid,
                                "timestamp": FieldValue.serverTimestamp()
                              });
                              messageController.clear();
                            }, icon: Icon(Icons.send))
                          ],
                        ))
                      ],
                    ),
                  );
                }
            );
          }
      ),
    );
  }
  Widget senderMessageBubble(String message){
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: EdgeInsets.all(8),
          decoration: BoxDecoration(
              color: AppColors.whiteColor,
              borderRadius: BorderRadius.circular(10)
          ),
          child: Text(message, style: TextStyle(color: AppColors.blackColor),),
        )
      ],
    );
  }
  Widget receiverMessageBubble(String message){
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: EdgeInsets.all(8),
          decoration: BoxDecoration(
              color: Colors.deepPurple,
              borderRadius: BorderRadius.circular(10)
          ),
          child: Text(message, style: TextStyle(color: AppColors.whiteColor),),
        )
      ],
    );
  }
}
