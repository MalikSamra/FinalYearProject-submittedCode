import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fypp/controllers/qecConsoleController/qecConsoleController.dart';
import 'package:fypp/utils/CustomTextStyles.dart';
import 'package:fypp/utils/appColors.dart';
import 'package:fypp/views/administrativeConsole/administrativeGeneral/tabs/members_data.dart';
import 'package:fypp/widgets/customButton.dart';
import 'package:get/get.dart';

import '../../../controllers/administrativeGeneralController/widgets/administrativeGeneralContainer.dart';

class QecGeneralScreen extends StatefulWidget {
  const QecGeneralScreen({super.key});

  @override
  State<QecGeneralScreen> createState() => _QecGeneralScreenState();
}

class _QecGeneralScreenState extends State<QecGeneralScreen> {
  QecConsoleController qecConsoleController = Get.put(QecConsoleController());

  @override
  void initState() {
    super.initState();
    qecConsoleController.fetchData();
  }

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Container(
      color: AppColors.lightBlue,
      padding: EdgeInsets.only(left: 20, right: 20),
      child: MembersData(MemberType: "qecmemberconsole"),
    );
  }
}
