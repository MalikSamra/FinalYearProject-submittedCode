import 'dart:typed_data';
import 'dart:ui';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import 'helper.dart';

class Report extends StatefulWidget {
  final List<Map<String, dynamic>> data;
  const Report({super.key, required this.data});

  @override
  State<Report> createState() => _ReportState();
}

class _ReportState extends State<Report> {

  String dateFormatter(Timestamp date){
    return "${date.toDate().day}/${date.toDate().month}/${date.toDate().year}";
  }
  final GlobalKey reportWidgetKey = GlobalKey();

  Future<Uint8List> widgetToImage(GlobalKey key) async {
    RenderRepaintBoundary boundary = key.currentContext!.findRenderObject() as RenderRepaintBoundary;
    var image = await boundary.toImage();
    ByteData? byteData = await image.toByteData(format: ImageByteFormat.png);
    return byteData!.buffer.asUint8List();
  }

  Future<void> _printWidgetToPdf() async {
    final image = await widgetToImage(reportWidgetKey);
    await printWidgetToPdf(image);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Center(
              child: RepaintBoundary(
                key: reportWidgetKey,
                child: Container(
                  height: MediaQuery.of(context).size.height * 0.9,
                  width: MediaQuery.of(context).size.width * 0.6,
                  color: Colors.white,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Center(child: Text("Generated Report", style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold
                        ),)),
                        SizedBox(
                          height: MediaQuery.sizeOf(context).height * 0.05,
                        ),
                        ListView.builder(
                          itemCount: widget.data.length,
                          shrinkWrap: true,
                          itemBuilder: (context, index){ {
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 30,),
                                Text("Course Name: ${widget.data[index]['courseName']}", style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold
                                ),),
                                const SizedBox(height: 10,),
                                Text("Course Code: ${widget.data[index]['courseCode']}", style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold
                                ),),
                                const SizedBox(height: 10,),
                                FutureBuilder(
                                  future: FirebaseFirestore.instance.collection("users").doc(widget.data[index]['facultyId']).get(),
                                  builder: (context, snapshot){
                                    if(snapshot.connectionState == ConnectionState.waiting){
                                      return Text("Assigned Faculty Name: Loading...", style: TextStyle(
                                        color: Colors.deepPurple
                                      ));
                                    }
                                    if(snapshot.hasError){
                                      return Text("Assigned Faculty Name: Error", style: TextStyle(
                                        color: Colors.red
                                      ));
                                    }

                                    return Text("Assigned Faculty Name: ${snapshot.data!['username']}", style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold
                                    ),);
                                  }
                                ),
                                const SizedBox(height: 10,),
                                Text("Assigned QEC Member: ${widget.data[index]['qecMember']}", style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold
                                ),),
                                const SizedBox(height: 10,),
                                Text("Last Updated: ${dateFormatter(widget.data[index]['last_updated'] as Timestamp)}", style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold
                                ),),
                                const SizedBox(height: 10,),
                                Text("Checked Files", style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold
                                ),),
                                const SizedBox(height: 10,),
                                ListView.builder(
                                  itemCount: widget.data[index]['checked_files'].length,
                                  shrinkWrap: true,
                                  itemBuilder: (context, i){
                                    return widget.data[index]["checked_files"][i].toString().isEmpty ? SizedBox() : ListTile(
                                      title: Text(widget.data[index]['checked_files'][i], style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.normal,
                                        fontStyle: FontStyle.italic
                                      ),),
                                      trailing: Text("✅"),
                                    );
                                  },
                                ),
                              ],
                            );
                          }
                          }
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20,),
            ElevatedButton(onPressed: _printWidgetToPdf, child: Text("Print Report"))
          ],
        ),
      ),),
    );
  }
}
