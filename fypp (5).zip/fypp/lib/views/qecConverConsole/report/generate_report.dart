import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:fypp/views/qecConverConsole/report/report.dart';

class GenerateReport extends StatefulWidget {
  const GenerateReport({super.key});

  @override
  State<GenerateReport> createState() => _GenerateReportState();
}

class _GenerateReportState extends State<GenerateReport> {
  List<Map<String, dynamic>> _data = [];
  List<FlSpot> graphData = [];
  bool _isLoading = true;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getData();
    setState(() {
      _isLoading = false;
    });
  }
  void getData()async{
    var snaps = await FirebaseFirestore.instance.collection("assignedCoursesQEC").orderBy("last_updated", descending: true).get();

    for(int i=0; i<snaps.docs.length; i++){
      var data = snaps.docs[i];
      _data.add(data.data());
    }
   graphData = List.generate(_data.length, (index) {
     Timestamp other = _data[index]['last_updated'];
      final daysAgo = DateTime.now().difference(DateTime.fromMicrosecondsSinceEpoch(other.microsecondsSinceEpoch)).inMinutes.toDouble();
      print(daysAgo);
      return FlSpot(daysAgo, index.toDouble());
    });
  }
  Future<Map<String, List<Map<String, dynamic>>>> fetchAndGroupData() async {
    // Fetch documents from Firestore collection
    var querySnapshot =
    await FirebaseFirestore.instance.collection("assignedCoursesQEC").orderBy("last_updated", descending: true).get();

    // Group data by 'id' field
    Map<String, List<Map<String, dynamic>>> groupedData = {};

    for (var doc in querySnapshot.docs) {
      var data = doc.data();
      String id = data['qecMemberId']; // Replace 'id' with your field name

      if (groupedData.containsKey(id)) {
        groupedData[id]?.add(data);
      } else {
        groupedData[id] = [data];
      }
    }

    return groupedData;
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:  Column(
        children: [
          SizedBox(
            height: MediaQuery.of(context).size.height * 0.9,
            width: MediaQuery.of(context).size.width,
            child: FutureBuilder(
                future: fetchAndGroupData(),
                builder: (context, snaps) {
                  if (snaps.connectionState == ConnectionState.waiting) {
                    return Container();
                  }
                  if (snaps.hasError) {
                    return Text('Error: ${snaps.error}');
                  }
                  return ListView.builder(itemBuilder: (context, index) {
                    var data = snaps.data!.values.toList()[index];
                    return Card(
                      child: ListTile(
                            title: Text(data[0]['qecMember']),
                            trailing: ElevatedButton(onPressed: (){
                              Navigator.push(context, MaterialPageRoute(builder: (context) => Report(data: data,)));
                            }, child: Text("Generate Report")),
                          )

                    );
                  }, itemCount: snaps.data!.length,);
                 /* var data = snaps.data!.docs.where((element) => element['isSubmitted'] == true).toList();
                  return data.length == 0 ? Center(
                    child: Text('No Data Found'),
                  ) : ListView.builder(
                    itemCount: snaps.data!.docs.length,
                    itemBuilder: (context, index) {
                      var data = snaps.data!.docs[index];
                      return  Card(
                        child: ListTile(
                          title: Text(data['courseName']),
                          subtitle: Text(data['qecMember']),
                          trailing: ElevatedButton(onPressed: (){
                            Navigator.push(context, MaterialPageRoute(builder: (context) => Report(data: data,)));
                          }, child: Text("Generate Report")),
                        ),
                      );
                    },
                  );*/
                }
            ),
          ),
        /*  SizedBox(
            height: MediaQuery.of(context).size.height * 0.5,
            width: MediaQuery.of(context).size.width,
            child: _isLoading ? Center(
              child: CircularProgressIndicator(),
            ) : Padding(
              padding: const EdgeInsets.all(16.0),
              child: LineChart(
                LineChartData(
                  gridData: FlGridData(show: true),
                  titlesData: FlTitlesData(
                    leftTitles: AxisTitles(
                        axisNameWidget: Text("Courses", style: TextStyle(color: Colors.black),),
                        sideTitles:  SideTitles(showTitles: true)),
                    bottomTitles: AxisTitles(
                      axisNameWidget:Text("Min Ago", style: TextStyle(color: Colors.black),) ,
                      sideTitles:  SideTitles(
                      showTitles: true,
                      getTitlesWidget: (value, meta) {
                        return Padding(padding: EdgeInsets.all(8.0), child: Text(value.toString() + " days ago"),);
                      },
                    ),)
                  ),
                  borderData: FlBorderData(show: true),
                  minY: 30,
                  minX: 0,

                  lineBarsData: [
                    LineChartBarData(
                      spots: graphData,
                      isCurved: true,
                      color: Colors.blue,
                      barWidth: 4,
                      belowBarData: BarAreaData(show: true, color: Colors.blue.withOpacity(0.3)),
                    ),
                  ],
                ),
              ),
            ),
          ),*/
        ],
      ),
    );
  }
}
