import 'dart:typed_data';
import 'dart:html' as html;
import 'dart:async';

Future<void> printWidgetToPdf(Uint8List image) async {
  final blob = html.Blob([image]);
  final url = html.Url.createObjectUrlFromBlob(blob);
  final anchor = html.AnchorElement(href: url)
    ..setAttribute("download", "report.png")
    ..click();
  await Future.delayed(Duration(seconds: 2));
  html.Url.revokeObjectUrl(url);
}