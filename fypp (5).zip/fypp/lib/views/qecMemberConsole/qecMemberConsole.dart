import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../utils/CustomTextStyles.dart';
import '../../utils/appColors.dart';
import '../../widgets/completePercentageContainer.dart';
import '../../widgets/customAppBar.dart';
import '../../widgets/customButton.dart';
import 'qecMemberDetailScreen/qecMemberDetailScreen.dart';

class QecMemberConsole extends StatefulWidget {
  const QecMemberConsole({super.key});

  @override
  State<QecMemberConsole> createState() => _QecMemberConsoleState();
}

class _QecMemberConsoleState extends State<QecMemberConsole> {
  String selectedUserId = '';
  String courseName= '';
  String courseCode = '';
  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: CustomAppBar(
        titleSpacing: 0.0,
        title: 'QEC Member Console',
      ),
      body: Padding(
        padding: EdgeInsets.only(left: 20, right: 20),
        child: Column(
          children: [

            SizedBox(height: height * 0.018),
            Container(
              padding:
                  EdgeInsets.only(top: 19, left: 23, right: 23, bottom: 23),
              decoration: BoxDecoration(
                border: Border.all(color: AppColors.primaryColor),
                borderRadius: BorderRadius.only(
                    topRight: Radius.circular(35),
                    topLeft: Radius.circular(35)),
              ),
              child: Column(
                children: [
                  Container(
                    padding: EdgeInsets.only(
                        top: 10, left: 14, right: 10, bottom: 10),
                    decoration: BoxDecoration(
                        color: AppColors.d9d9d9,
                        borderRadius: BorderRadius.circular(35),
                        border: Border.all(
                            color: AppColors.primaryColor, width: 1)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Teacher Name'),
                        Text('Coarse Name'),
                        Text('Coarse No.'),
                        Text('Credits'),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 20),
                    child: FutureBuilder(future: FirebaseFirestore.instance.collection("assignedCoursesQEC").get(), builder:(context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return Center(
                          child: CircularProgressIndicator(),
                        );
                      }
                      if (snapshot.hasError) {
                        return Center(
                          child: Text('Error: ${snapshot.error}'),
                        );
                      }
                      var courses = snapshot.data!.docs;
                     return ListView.builder(
                       itemCount: courses.length,
                       shrinkWrap: true,
                       itemBuilder: (context, index) {
                       return FutureBuilder(
                          future: FirebaseFirestore.instance.collection('users').doc(courses[index]['facultyId']).get(),

                         builder: (context, snp) {
                            if (snp.connectionState == ConnectionState.waiting) {
                              return Center(
                                child: CircularProgressIndicator(),
                              );
                            }
                            if (snp.hasError) {
                              return Center(
                                child: Text('Error: ${snp.error}'),
                              );
                            }
                           return Padding(
                             padding: const  EdgeInsets.only(
                                 top: 10, left: 14, right: 10, bottom: 10),
                             child: InkWell(
                               onTap: ()async {
                                 setState(() {
                                    selectedUserId = courses[index]['facultyId'];
                                    courseName = courses[index]['courseName'];
                                    courseCode = courses[index]['courseCode'];
                                 });

                                 var data = await FirebaseFirestore.instance.collection('courses').doc(courses[index]['courseCode']).get();
                                 var lab_credits = data['lab_credits'];
                                 Get.to(QecMemberDetailScreen(facId: selectedUserId, courseName: courseName, courseCode: courseCode, lab_credits: lab_credits, id: courses[index].id));
                               },
                               child: Row(
                                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                 children: [
                                   Text('${snp.data!['username']}'),
                                   Text('${courses[index]['courseName']}'),
                                   Text('${courses[index]['courseCode']}'),
                                   FutureBuilder(
                                      future: FirebaseFirestore.instance.collection('courses').doc(courses[index]['courseCode']).get(),
                                     builder: (context, snps) {
                                        if (snps.connectionState == ConnectionState.waiting) {
                                          return Center(
                                            child: CircularProgressIndicator(),
                                          );
                                        }
                                        if (snps.hasError) {
                                          return Center(
                                            child: Text('Error: ${snps.error}'),
                                          );
                                        }

                                       return Text('(${snps.data!['theory_credits']}, ${snps.data!['lab_credits']})');
                                     }
                                   ),
                                 ],
                               ),
                             ),
                           );
                         }
                       );
                     },);})
                  ),
                  SizedBox(height: height * 0.03),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
/*
IntrinsicHeight(
child: InkWell(
onTap: () {
Get.to(QecMemberDetailScreen());
},
child: Row(
mainAxisAlignment: MainAxisAlignment.spaceBetween,
crossAxisAlignment: CrossAxisAlignment.start,
children: [
Padding(
padding: const EdgeInsets.only(top: 20),
child: Text('SIR KAMRAN KHAN'),
),
SizedBox(width: width * 0.02),
Container(
color: AppColors.primaryColor,
height: height * 0.3,
width: 1,
),
SizedBox(width: width * 0.02),
Padding(
padding: const EdgeInsets.only(top: 20),
child: Text('SP21-0046'),
),
SizedBox(width: width * 0.02),
VerticalDivider(
color: AppColors.primaryColor,
),
SizedBox(width: width * 0.02),
Padding(
padding: const EdgeInsets.only(top: 20),
child: Text('OPERATING SYSTEM '),
),
SizedBox(width: width * 0.02),
VerticalDivider(
color: AppColors.primaryColor,
),
SizedBox(width: width * 0.02),
Padding(
padding: const EdgeInsets.only(top: 20),
child: Text('SP21-0046'),
),
SizedBox(width: width * 0.02),
VerticalDivider(
color: AppColors.primaryColor,
),
SizedBox(width: width * 0.02),
Padding(
padding: const EdgeInsets.only(top: 20),
child: Text('3'),
),
SizedBox(width: width * 0.02),
VerticalDivider(
color: AppColors.primaryColor,
),
SizedBox(width: width * 0.02),
CompletePercentageContainer(
text: '75%',
),
SizedBox(width: width * 0.02),
VerticalDivider(
color: AppColors.primaryColor,
),
SizedBox(width: width * 0.02),
Padding(
padding: const EdgeInsets.only(top: 20),
child: Stack(
children: <Widget>[
Container(
decoration: BoxDecoration(
color: AppColors.whiteColor,
border: Border.all(
color: AppColors.primaryColor),
borderRadius:
BorderRadius.circular(35)),
width: width * 0.1,
height: height * 0.03,
),
Container(
decoration: BoxDecoration(
color: AppColors.primaryColor,
borderRadius:
BorderRadius.circular(35)),
width: width * 0.08,
height: height * 0.03,
child: Center(
child: Text(
'85%',
style: CustomTextStyles.l17_white,
),
),
),
],
),
),
],
),
),
),*/
