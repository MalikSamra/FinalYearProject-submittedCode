import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:pdfx/pdfx.dart';


class FilePreviewer extends StatefulWidget {
  final String fileUrl;

  FilePreviewer({required this.fileUrl});

  @override
  State<FilePreviewer> createState() => _FilePreviewerState();
}

class _FilePreviewerState extends State<FilePreviewer> {
  // Method to check if the file is an image or PDF based on its extension
  bool _isImage(String url) {
    final imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp'];
    return imageExtensions.any((ext) => url.toLowerCase().contains(ext));
  }

  initState() {
    super.initState();
    print(_isImage(widget.fileUrl));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: _isImage(widget.fileUrl)
            ? InteractiveViewer(child: Image.network(widget.fileUrl)) // Display image from URL
            : _buildPdfViewer(widget.fileUrl), // Display PDF from URL
      ),
    );
  }

  // PDF Viewer Widget
  Widget _buildPdfViewer(String url) {
    return PdfView(
            controller: PdfController(
              document: _loadPdf(url),
            ),
          );


  }

  // Load the PDF from the URL
  Future<PdfDocument> _loadPdf(String url) async {
    final pdfData = await _downloadFile(url);
    return PdfDocument.openData(pdfData);
  }

  // Download the file (PDF or other media) from the URL
  FutureOr<Uint8List> _downloadFile(String url) async {
    final response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      return response.bodyBytes;
    } else {
      throw Exception('Failed to load file');
    }
  }
}
