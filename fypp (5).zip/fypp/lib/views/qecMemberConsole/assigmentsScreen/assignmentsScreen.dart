import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:fypp/assetsPath/assetsPath.dart';
import 'package:fypp/controllers/loginController/loginController.dart';
import 'package:fypp/controllers/user_controller.dart';
import 'package:fypp/utils/appColors.dart';
import 'package:fypp/views/qecMemberConsole/assigmentsScreen/previewer.dart';
import 'package:get/get.dart';

class AssigmentsScreen extends StatefulWidget {
  final String title;
  final String facId;
  final String courseCode;
  const AssigmentsScreen({super.key, required this.title, required this.facId, required this.courseCode});

  @override
  State<AssigmentsScreen> createState() => _AssigmentsScreenState();
}

class _AssigmentsScreenState extends State<AssigmentsScreen> {
  bool isActive = true;

  var collectionPath = "";


  void toggleState() {
    setState(() {
      isActive = !isActive;
    });
  }




  @override
  Widget build(BuildContext context) {
    var height = MediaQuery
        .of(context)
        .size
        .height;
    var width = MediaQuery
        .of(context)
        .size
        .width;
    var userController = Get.find<UserController>();
    return Scaffold(
        body: widget.title.contains("Quiz") || widget.title.contains("Assignment") ?  ListView.builder(
          shrinkWrap: true, itemCount: 4, itemBuilder: (context, index) {
            print("${widget.title.toLowerCase().replaceAll(" ", "_")}_number_${index +
                1}");
          return StreamBuilder(
            stream: FirebaseFirestore.instance.collection("uploaded_files").doc(
                "${widget.facId}_${widget.courseCode}").collection(
                "${widget.title.toLowerCase().replaceAll(" ", "_")}_number_${index +
                    1}").snapshots(), builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Container();
            }
            if (snapshot.hasError) {
              return Text('Error: ${snapshot.error}');
            }
            if(snapshot.data!.docs.isEmpty) {
              return SizedBox(

              );
            }
            return ListView.builder(itemBuilder: (context, indexL) {
              var data = snapshot.data!.docs[indexL];
              return Center(
                child: Container(
                  height: height * 0.3,
                  width: width * 0.9,
                  child: Column(

                    children: [
                      Text('${widget.title} Number ${index + 1} ${data["title"].toString().replaceAll("_", " ")}'),
                      SizedBox(height: height * 0.025),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                         InkWell(
                           onTap: () {
                             showDialog(
                               context: context,
                               builder: (context) => Dialog(
                                 backgroundColor: Colors.transparent,
                                 child: GestureDetector(
                                   onTap: () => Navigator.pop(context),
                                   child: Container(
                                     child: InteractiveViewer(
                                       child: Image.network(
                                         data['url'],
                                         fit: BoxFit.contain,
                                       ),
                                     ),
                                   ),
                                 ),
                               ),
                             );
                           },
                           child: Container(
                                height: height * 0.2,
                                width: width * 0.5,
                                child: Image.network(data['url'], fit: BoxFit.cover,)),
                         ),


                      Container(
                        height: height * 0.15,
                        width: width * 0.2,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            InkWell(
                              onTap: () async{
                                FirebaseFirestore.instance.collection("uploaded_files").doc(
                                    "${widget.facId}_${widget.courseCode}").collection(
                                    "${widget.title.toLowerCase().replaceAll(" ", "_")}_number_${index +
                                        1}").doc(data.id).update({
                                  "isChecked": true
                                });
                                await FirebaseFirestore.instance.collection("assignedCoursesQEC").where("courseCode", isEqualTo: widget.courseCode).get().then((value) {
                                  var doc = value.docs.where((element) => element["qecMemberId"] == userController.userModal!.uid,).first;
                                   var checked = doc.data()["checked_files"] as List;
                                if(checked.contains("${widget.title} Number ${index + 1} ${data["title"].toString().replaceAll("_", " ")}")){

                                } else {
                                  checked.add("${widget.title} Number ${index + 1} ${data["title"].toString().replaceAll("_", " ")}");
                                }

                                    FirebaseFirestore.instance.collection("assignedCoursesQEC").doc(doc.id).update({
                                      "last_updated": DateTime.now(),
                                      "checked_files": checked
                                    });
                                  });

                              },
                              child: Row(
                                children: [
                                  Image.asset(
                                    '${Assets.imagesPath}${!data["isChecked"]  ? Assets.inActive : Assets.active}',
                                  ),
                                  SizedBox(width: width * 0.01),
                                  Text('Checked')
                                ],
                              ),
                            ),
                            SizedBox(height: height * 0.02),
                            InkWell(
                              onTap: () async{
                                FirebaseFirestore.instance.collection("uploaded_files").doc(
                                    "${widget.facId}_${widget.courseCode}").collection(
                                    "${widget.title.toLowerCase().replaceAll(" ", "_")}_number_${index +
                                        1}").doc(data.id).update({
                                  "isChecked": false
                                });

                                await FirebaseFirestore.instance.collection("assignedCoursesQEC").where("courseCode", isEqualTo: widget.courseCode).get().then((value) {
                                  var doc = value.docs.where((element) => element["qecMemberId"] == userController.userModal!.uid,).first;
                                  var checked = doc.data()["checked_files"] as List;
                                  if(!checked.contains("${widget.title} Number ${index + 1} ${data["title"].toString().replaceAll("_", " ")}")){

                                  } else {
                                    checked.remove("${widget.title} Number ${index + 1} ${data["title"].toString().replaceAll("_", " ")}");
                                  }

                                  FirebaseFirestore.instance.collection("assignedCoursesQEC").doc(doc.id).update({
                                    "last_updated": DateTime.now(),
                                    "checked_files": checked
                                  });

                                });
                               /* var checked = value.docs.first.data()["checked"] as List;
                                if(checked.contains("${widget.title} Number ${index + 1}")){

                                } else {
                                  checked.remove("${widget.title} Number ${index + 1}");
                                }*/
                              },
                              child: Row(
                                children: [
                                  Image.asset(
                                    '${Assets.imagesPath}${!data["isChecked"] ? Assets.active : Assets.inActive}',
                                  ),
                                  SizedBox(width: width * 0.01),
                                  Text('UnChecked')
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),

                        ],
                      ),
                    ],
                  ),
                ),
              );
            } , itemCount: snapshot.data!.docs.length, shrinkWrap: true,);
          },);
        },) : StreamBuilder(
          stream: FirebaseFirestore.instance.collection("uploaded_files").doc(
              "${widget.facId}_${widget.courseCode}").collection(
              widget.title.toLowerCase().replaceAll(" ", "_").trim()).snapshots(),
          builder: (context, snapshot) {
            print("${widget.facId}_${widget.courseCode}" + "/" +widget.title.toLowerCase().replaceAll(" ", "_"));
          if (snapshot.connectionState == ConnectionState.waiting) {
            print("Waiting");
            return Container();
          }

          if (snapshot.hasError) {
            return Text('Error:  ${snapshot.error}');
          }
          if(snapshot.data!.docs.isEmpty || snapshot.data == null) {
            FirebaseFirestore.instance.collection("uploaded_files").doc(
                "${widget.facId}_${widget.courseCode}").collection(
                "${widget.title.toLowerCase().replaceAll(" ", "_").trim()}").get().then((value) {
                  print(value.docs.length);
                },);
            print("Empty");

            return SizedBox(
              child: Center(
                child: Text("No Data Found"),
              ),
            );
          }
          print(snapshot.data!.docs.first.id);
          return ListView.builder(itemBuilder: (context, index) {
            var data = snapshot.data!.docs[index];
            return Center(
              child: Container(
                height: height * 0.3,
                width: width * 0.9,
                child: Column(

                  children: [
                    Text('${widget.title}'),
                    SizedBox(height: height * 0.025),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        InkWell(
                          onTap: () {
                            showDialog(
                              context: context,
                              builder: (context) => Dialog(
                                backgroundColor: Colors.transparent,
                                child: GestureDetector(
                                  onTap: () => Navigator.pop(context),
                                  child: Container(
                                    child: FilePreviewer(fileUrl: data['url'])
                                  ),
                                ),
                              ),
                            );
                          },
                          child: Container(
                              height: height * 0.2,
                              width: width * 0.5,
                              child: FilePreviewer(fileUrl: data['url'])),
                        ),


                        Container(
                          height: height * 0.15,
                          width: width * 0.2,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              InkWell(
                                onTap: () async{
                                  await FirebaseFirestore.instance.collection("uploaded_files").doc(
                                      "${widget.facId}_${widget.courseCode}").collection(
                                      widget.title.toLowerCase().replaceAll(" ", "_")).doc(data.id).update({
                                    "isChecked": true
                                  });
                                  await FirebaseFirestore.instance.collection("assignedCoursesQEC").where("courseCode", isEqualTo: widget.courseCode).get().then((value) {
                                    var doc = value.docs.where((element) => element["qecMemberId"] == userController.userModal!.uid,).first;
                                    var checked = doc.data()["checked_files"] as List;
                                    if(checked.contains("${widget.title}")){

                                    } else {
                                      checked.add("${widget.title}");
                                    }

                                      FirebaseFirestore.instance.collection("assignedCoursesQEC").doc(doc.id).update({
                                        "last_updated": DateTime.now(),
                                        "checked_files": checked
                                      });
                                    });

                                },
                                child: Row(
                                  children: [
                                    Image.asset(
                                      '${Assets.imagesPath}${!data["isChecked"]  ? Assets.inActive : Assets.active}',
                                    ),
                                    SizedBox(width: width * 0.01),
                                    Text('Checked')
                                  ],
                                ),
                              ),
                              SizedBox(height: height * 0.02),
                              InkWell(
                                onTap: () async{
                                  await FirebaseFirestore.instance.collection("uploaded_files").doc(
                                      "${widget.facId}_${widget.courseCode}").collection(
                                      widget.title.toLowerCase().replaceAll(" ", "_")).doc(data.id).update({
                                    "isChecked": false
                                  });
                                  await FirebaseFirestore.instance.collection("assignedCoursesQEC").where("courseCode", isEqualTo: widget.courseCode).get().then((value) {
                                    var doc = value.docs.where((element) => element["qecMemberId"] == userController.userModal!.uid,).first;
                                    var checked = value.docs.first.data()["checked_files"] as List;
                                    if(checked.contains("${widget.title}")){

                                    } else {
                                      checked.remove("${widget.title}");
                                    }

                                      FirebaseFirestore.instance.collection("assignedCoursesQEC").doc(doc.id).update({
                                        "last_updated": DateTime.now(),
                                        "checked_files": checked


                                    });
                                  });
                                },
                                child: Row(
                                  children: [
                                    Image.asset(
                                      '${Assets.imagesPath}${!data["isChecked"] ? Assets.active : Assets.inActive}',
                                    ),
                                    SizedBox(width: width * 0.01),
                                    Text('UnChecked')
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),

                      ],
                    ),
                  ],
                ),
              ),
            );
          } , itemCount: snapshot.data!.docs.length, shrinkWrap: true,);
        },));
  }
}
/*
  StreamBuilder(
  stream: FirebaseFirestore.instance.collectionGroup('uploaded_files}').snapshots(),
  builder: (context, snap) {
  if(snap.connectionState == ConnectionState.waiting) {
  return CircularProgressIndicator();
  }
  if(snap.hasError) {
  return Text('Error: ${snap.error}');
  }
  print(snap.data!.docs.first.id);
  return Container(
  color: AppColors.backGroundColor,
  padding: EdgeInsets.only(top: 50, right: 25, left: 25),
  child: Column(
  crossAxisAlignment: CrossAxisAlignment.start,
  children: [
  Text('Assignment Number 1'),
  SizedBox(height: height * 0.025),
  Row(
  children: [
  Container(
  color: AppColors.d9d9d9,
  padding: EdgeInsets.only(
  top: height * 0.023,
  bottom: height * 0.026,
  left: height * 0.020,
  right: height * 0.020,
  ),
  child: Stack(
  children: [
  Image.asset(
  '${Assets.imagesPath}${Assets.assmntPic}',
  height: height * 0.1,
  ),
  Positioned(
  right: 0,
  bottom: 0,
  child: Icon(Icons.remove_red_eye_outlined))
  ],
  ),
  ),
  SizedBox(width: width * 0.027),
  GestureDetector(
  onTap: toggleState,
  child: Column(
  crossAxisAlignment: CrossAxisAlignment.start,
  children: [
  Row(
  children: [
  Image.asset(
  '${Assets.imagesPath}${isActive ? Assets.inActive : Assets.active}',
  ),
  SizedBox(width: width * 0.01),
  Text('Checked')
  ],
  ),
  SizedBox(height: height * 0.02),
  Row(
  children: [
  Image.asset(
  '${Assets.imagesPath}${isActive ? Assets.active : Assets.inActive}',
  ),
  SizedBox(width: width * 0.01),
  Text('UnChecked')
  ],
  ),
  ],
  ),
  ),
  ],
  ),
  SizedBox(height: height * 0.1),
  Row(
  children: [
  Container(
  color: AppColors.d9d9d9,
  padding: EdgeInsets.only(
  top: height * 0.023,
  bottom: height * 0.026,
  left: height * 0.020,
  right: height * 0.020,
  ),
  child: Stack(
  children: [
  Image.asset(
  '${Assets.imagesPath}${Assets.assmntPic}',
  height: height * 0.1,
  ),
  Positioned(
  right: 0,
  bottom: 0,
  child: Icon(Icons.remove_red_eye_outlined))
  ],
  ),
  ),
  SizedBox(width: width * 0.027),
  GestureDetector(
  onTap: toggleState,
  child: Column(
  crossAxisAlignment: CrossAxisAlignment.start,
  children: [
  Row(
  children: [
  Image.asset(
  '${Assets.imagesPath}${isActive ? Assets.inActive : Assets.active}',
  ),
  SizedBox(width: width * 0.01),
  Text('Checked')
  ],
  ),
  SizedBox(height: height * 0.02),
  Row(
  children: [
  Image.asset(
  '${Assets.imagesPath}${isActive ? Assets.active : Assets.inActive}',
  ),
  SizedBox(width: width * 0.01),
  Text('UnChecked')
  ],
  ),
  ],
  ),
  ),
  ],
  )
  ],
  ),
  );
  }
  );*/
