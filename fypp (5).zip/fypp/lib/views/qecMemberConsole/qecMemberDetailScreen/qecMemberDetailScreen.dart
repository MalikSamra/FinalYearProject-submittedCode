import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:fypp/widgets/customAppBar.dart';
import 'package:get/get.dart';

import '../../../utils/appColors.dart';
import '../../../widgets/customTextField.dart';
import 'widgets/detailWidget.dart';

class QecMemberDetailScreen extends StatefulWidget {
  final String facId;
  final String courseName;
  final String courseCode;
  final String lab_credits;
  final String id;
  const QecMemberDetailScreen({super.key, required this.facId, required this.courseName, required this.courseCode, required this.lab_credits, required this.id});

  @override
  State<QecMemberDetailScreen> createState() => _QecMemberDetailScreenState();
}

class _QecMemberDetailScreenState extends State<QecMemberDetailScreen> {


  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: CustomAppBar(
        titleSpacing: 0.0,
        title: 'QEC Conver Console',
      ),
      body: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.only(top: 50, left: 30, bottom: 20, right: 50),
            width: width * 0.25,
            color: AppColors.whiteColor,
            child: FutureBuilder(
              future: FirebaseFirestore.instance.collection('users').doc(widget.facId).get(),
              builder: (context, snap) {
                if(snap.connectionState == ConnectionState.waiting) {
                  return CircularProgressIndicator();
                }
                var data = snap.data as DocumentSnapshot;
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(data['username']),
                    SizedBox(height: height * 0.04),
                    Text(widget.courseName),

                    Expanded(child: Container()),
                    ElevatedButton(onPressed: ()async{
                      await FirebaseFirestore.instance.collection("assignedCoursesQEC").doc(widget.id).update({
                        'isSubmitted': true
                      });
                      Get.showSnackbar(GetBar(message: 'Submitted Successfully'));
                    }, child: Text('Submit')),
                    SizedBox(height: height * 0.04),
                  ],
                );
              }
            ),
          ),
          Expanded(child: MemberDetailContainer(
            facId: widget.facId,
            courseCode: widget.courseCode,
            lab_credits: int.parse(widget.lab_credits),
          )),
        ],
      ),
    );
  }
}
