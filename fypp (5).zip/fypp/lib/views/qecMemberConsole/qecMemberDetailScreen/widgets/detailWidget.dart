import 'package:flutter/material.dart';
import 'package:fypp/views/qecMemberConsole/assigmentsScreen/assignmentsScreen.dart';

import '../../../../utils/CustomTextStyles.dart';
import '../../../../utils/appColors.dart';

class MemberDetailContainer extends StatefulWidget {
  final String facId;
  final String courseCode;
  final int lab_credits;
  const MemberDetailContainer({
    Key? key, required this.facId, required this.courseCode, required this.lab_credits,
  }) : super(key: key);

  @override
  State<MemberDetailContainer> createState() => _CalenderScreenState();
}

class _CalenderScreenState extends State<MemberDetailContainer>
    with TickerProviderStateMixin {
  TabController? tabcontroller;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    tabcontroller = TabController(length: widget.lab_credits == 0 ? 5 : 8, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          DefaultTabController(
            length: widget.lab_credits > 0 ? 8 : 5,
            child: Column(
              children: [
                Container(
                  padding: EdgeInsets.only(top: 20),
                  color: AppColors.backGroundColor,
                  child: TabBar(
                    tabAlignment: TabAlignment.start,
                    overlayColor: MaterialStateProperty.all(Colors.transparent),
                    automaticIndicatorColorAdjustment: true,
                    dividerColor: AppColors.backGroundColor,
                    unselectedLabelColor: AppColors.unSelectedtabsColor,
                    labelColor: AppColors.whiteColor,
                    labelPadding: EdgeInsets.only(left: 15),
                    isScrollable: true,
                    indicator: BoxDecoration(
                      borderRadius: BorderRadius.circular(32),
                      border: Border.all(color: AppColors.primaryColor),
                    ),
                    controller: tabcontroller,
                    tabs:  widget.lab_credits == 0 ? [
                      _buildTab('CDF'),
                      _buildTab('Assignments'),
                      _buildTab('Quizes'),
                      _buildTab('Midterm'),
                      _buildTab('Final'),
                    ] : [
                      _buildTab('CDF'),
                      _buildTab('Assignments'),
                      _buildTab('Lab Assignments'),
                      _buildTab('Quizes'),
                      _buildTab('Midterm'),
                      _buildTab("Lab Midterm"),
                      _buildTab('Final'),
                      _buildTab('Lab Final'),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Flexible(
            child: TabBarView(controller: tabcontroller, children: widget.lab_credits == 0 ? [
              AssigmentsScreen(
                title: 'CDF',
                facId: widget.facId,
                courseCode: widget.courseCode,
              ),
              AssigmentsScreen(
                title: 'Assignment',
                facId: widget.facId,
                courseCode: widget.courseCode,
              ),
              AssigmentsScreen(
                title: 'Quiz',
                facId: widget.facId,
                courseCode: widget.courseCode,
              ),
              AssigmentsScreen(
                title: 'Midterm',
                facId: widget.facId,
                courseCode: widget.courseCode,
              ),
              AssigmentsScreen(
                title: 'Final',
                facId: widget.facId,
                courseCode: widget.courseCode,
              ),
            ] : [
              AssigmentsScreen(
                title: 'cdf',
                facId: widget.facId,
                courseCode: widget.courseCode,
              ),
              AssigmentsScreen(
                title: 'Assignment',
                facId: widget.facId,
                courseCode: widget.courseCode,
              ),
              AssigmentsScreen(
                title: 'Lab Assignment',
                facId: widget.facId,
                courseCode: widget.courseCode,
              ),
              AssigmentsScreen(
                title: 'Quiz',
                facId: widget.facId,
                courseCode: widget.courseCode,
              ),
              AssigmentsScreen(
                title: 'Midterm',
                facId: widget.facId,
                courseCode: widget.courseCode,
              ),
              AssigmentsScreen(
                title: 'Lab Midterm',
                facId: widget.facId,
                courseCode: widget.courseCode,
              ),
              AssigmentsScreen(
                title: 'Lab Final',
                facId: widget.facId,
                courseCode: widget.courseCode,
              ),
              AssigmentsScreen(
                title: 'Final',
                facId: widget.facId,
                courseCode: widget.courseCode,
              ),

            ]),
          ),
        ],
      ),
    );
  }
}

//
Widget _buildTab(String label) {
  return Container(
    height: 42,
    decoration: BoxDecoration(borderRadius: BorderRadius.circular(35)),
    child: Tab(
      child: Center(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 15.0),
          child: Text(label, style: CustomTextStyles.l24_black),
        ),
      ),
    ),
  );
}
