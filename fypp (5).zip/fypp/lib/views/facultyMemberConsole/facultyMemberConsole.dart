import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:fypp/controllers/loginController/loginController.dart'; // Import the login controller
import 'package:fypp/controllers/user_controller.dart';
import 'package:fypp/views/facultyMemberConsole/facCommunicateScreen/facCommunicateScreen.dart';
import 'package:fypp/widgets/completePercentageContainer.dart';
import 'package:fypp/widgets/customAppBar.dart';
import 'package:fypp/widgets/customDropDown.dart';
import 'package:get/get.dart'; // Import Get for reactive state management

import '../../../utils/appColors.dart';
import '../../../widgets/customTextField.dart';
import '../../utils/CustomTextStyles.dart';
import '../../widgets/roundedContainer.dart';
import 'facultyMemberDetailScreen/facultyMemberScreen.dart';

class FacultyMemberConsole extends StatefulWidget {
  const FacultyMemberConsole({super.key});

  @override
  State<FacultyMemberConsole> createState() => _FacultyMemberConsoleState();
}

class _FacultyMemberConsoleState extends State<FacultyMemberConsole> with TickerProviderStateMixin{
  TextEditingController sub1TextEditingController =
      TextEditingController();
  TextEditingController sub2EditingController =
      TextEditingController();
  String selectedCourse = '';
  var selectedTab = 0;
  bool isLAb = false;

  @override
  Widget build(BuildContext context) {
    var loginController = Get.find<UserController>(); // Get the login controller
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return FutureBuilder(
      future: FirebaseFirestore.instance.collection("assignedCourses").get(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        }
        if (snapshot.hasError) {
          return Scaffold(
            body: Center(
              child: Text('Error: ${snapshot.error}'),
            ),
          );
        }
        var assignedCoursesToFaculty = snapshot.data!.docs.where((element) => element['facId'] == loginController.userModal!.uid).toList();
        return Scaffold(
          appBar: CustomAppBar(
            titleSpacing: 0.0,
            title: 'Faculty Member Console',
            trailing: CustomDropDown(hint: this.selectedCourse == "" ? "Select Course" : this.selectedCourse, items: assignedCoursesToFaculty.map((e) => e["courseName"] as String,).toList(), onChangedValue: (p0) {
              var selectedCourse = assignedCoursesToFaculty.firstWhere((element) => element['courseName'] == p0);
              print(selectedCourse);
              loginController.setFacultyCourse({
                "courseCode": selectedCourse["courseCode"],
                "courseName": selectedCourse["courseName"],
                "facId": selectedCourse["facId"],
                "labCredits": selectedCourse["labCredits"],
                "theoryCredits": selectedCourse["theoryCredits"],
              });
              loginController.setFacultySelectedCourse(selectedCourse["courseCode"]);
              setState(() {
                isLAb = int.parse(selectedCourse["labCredits"].toString())> 0;
                this.selectedCourse = selectedCourse["courseCode"];
              });
            },
            fillColor: AppColors.primaryColor,
              hintStyle: TextStyle(
                color: AppColors.whiteColor,
                fontSize: 20,
              ),
              textStyle: TextStyle(
                color: AppColors.blackColor,
                fontSize: 20,
              ),

            ),
          ),
          body: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: width * 0.2,
                color: AppColors.whiteColor,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ListTile(
                      title: Text('Home', style: TextStyle(
                        fontSize: 20,
                      ),),
                      onTap: () {
                        setState(() {
                          selectedTab = 0;
                        });
                      },
                      selected: selectedTab == 0,
                    ),
                    ListTile(
                      title: Text('Communicate', style: TextStyle(
                        fontSize: 20,
                      ),),
                      onTap: () {
                        setState(() {
                          selectedTab = 1;
                        });
                      },
                      selected: selectedTab == 1,
                    ),
                    this.selectedCourse != '' ? ListTile(
                      title: Text('Progress', style: TextStyle(
                        fontSize: 20,
                      ),),

                    ) : SizedBox(),
                    this.selectedCourse != '' ?   StreamBuilder(
                      stream: FirebaseFirestore.instance
                          .collection('progress').doc("${loginController.userModal!.uid}_${loginController.facultySelectedCourse}").collection(selectedCourse).doc("progress").snapshots(),
                      builder: (context, snap) {
                        if(snap.connectionState == ConnectionState.waiting) {
                          return LinearProgressIndicator(
                            value: 0,
                            backgroundColor: AppColors.whiteColor,
                            valueColor: AlwaysStoppedAnimation<Color>(AppColors.primaryColor),
                          );
                        }
                        if(snap.hasError) {
                          return LinearProgressIndicator(
                            value: 0,
                            backgroundColor: AppColors.whiteColor,
                            valueColor: AlwaysStoppedAnimation<Color>(AppColors.primaryColor),
                          );
                        }
                        if(snap.data!.exists == false) {
                          return LinearProgressIndicator(
                            value: 0,
                            backgroundColor: AppColors.whiteColor,
                            valueColor: AlwaysStoppedAnimation<Color>(AppColors.primaryColor),
                          );
                        }
                        var data = snap.data!;
                        int count = data['uploadedCount'];
                        return Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: LinearProgressIndicator(
                            value: !isLAb ? count / 51 : count / 81,
                            borderRadius: BorderRadius.circular(100),
                            minHeight: 8,
                            color: AppColors.primaryColor,
                            backgroundColor: AppColors.whiteColor,
                            valueColor: AlwaysStoppedAnimation<Color>(AppColors.primaryColor),
                          ),
                        );
                      }
                    ) : SizedBox(),
                    Expanded(child: SizedBox()),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: RoundedContainerImage(
                        text: 'prof',
                        name: loginController.userModal!.username,
                        iText: '',
                        widthh: width * 0.18,
                      ),
                    ),
                  ],
                ),
              ),
            Flexible(child: selectedTab == 0 ? this.selectedCourse == ''?  Center(
              child: Text('Please select a course', style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),),
            ) : FacultyMemberDetailScreen() : Faccommunicatescreen())
            /*  Container(
                padding: EdgeInsets.only(top: 50, left: 30, bottom: 20, right: 20),
                width: width * 0.2,
                color: AppColors.whiteColor,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                       // RoundedTextField(
                         // textEditingController: sub1TextEditingController,
                       //   isActive: false,
                       //   width: width * 0.15,
                       // ),
                       // SizedBox(width: width * 0.02),
                        CompletePercentageContainer(
                          text: '75%',
                          widthh: width * 0.1,
                          width1: width * 0.1,
                        ),
                      ],
                    ),
                    SizedBox(height: height * 0.05),
                    Row(
                      children: [
                       // RoundedTextField(
                        //  textEditingController: sub1TextEditingController,
                         // isActive: false,
                         // width: width * 0.15,
                       // ),
                       // SizedBox(width: width * 0.02),
                        CompletePercentageContainer(
                          text: '95%',
                          widthh: width * 0.1,
                          width1: width * 0.1,
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    // Display the username

                   RoundedContainerImage(
                        text: 'prof',
                        name: loginController.userModal!.username,
                        iText: '',
                        widthh: width * 0.18,
                   ),

                  ],
                ),
              ),*/
              /*Expanded(child: this.selectedCourse == ''?  Center(
                child: Text('Please select a course', style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),),
              ) : FacultyMemberDetailScreen()),*/
            ],
          ),
        );
      }
    );
  }
}
