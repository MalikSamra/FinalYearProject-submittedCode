// lib/views/facultyMemberConsole/facultyMemberDetailScreen/facultyMemberDetailScreen.dart

import 'package:flutter/material.dart';
import 'package:fypp/controllers/user_controller.dart';
import 'package:fypp/utils/CustomTextStyles.dart';
import 'package:fypp/utils/appColors.dart';
import 'package:fypp/views/facultyMemberConsole/facultyMemberAssignmentsScreen/FacultyMemberLabFinalScreen.dart';
import 'package:fypp/widgets/customButton.dart';
import 'package:get/get.dart';

import '../facultyMemberAssignmentsScreen/FaccultyMemberQuizzesScreen.dart';
import '../facultyMemberAssignmentsScreen/FacultyMemberFinalScreen.dart';
import '../facultyMemberAssignmentsScreen/FacultyMemberLabAsgScreen.dart';
import '../facultyMemberAssignmentsScreen/FacultyMemberLabMidScreen.dart';
import '../facultyMemberAssignmentsScreen/facultyMemberAssignmentsScreen.dart';
import '../facultyMemberAssignmentsScreen/facultyMemberCDFScreen.dart'; // Import the new CDF screen
import '../facultyMemberAssignmentsScreen/facultyMemberMidtermScreen.dart';

class FacultyMemberDetailScreen extends StatefulWidget {
  const FacultyMemberDetailScreen({Key? key}) : super(key: key);

  @override
  State<FacultyMemberDetailScreen> createState() =>
      _FacultyMemberDetailScreenState();
}

class _FacultyMemberDetailScreenState extends State<FacultyMemberDetailScreen>
    with TickerProviderStateMixin {
  TabController? tabController;

  @override
  void initState() {
    super.initState();
    var user = Get.find<UserController>();
    tabController = TabController(
        length:int.parse(user.facultyCourse["labCredits"]) <= 0 ? 5 : 8, vsync: this); // Updated length to 5 to include CDF
  }

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return GetBuilder<UserController>(
      builder: (controller) {
        return Scaffold(
          backgroundColor: AppColors.backGroundColor,
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              DefaultTabController(
                length: 5, // Updated length to 5 to include CDF
                child: Row(
                  children: [
                    Container(
                      padding: EdgeInsets.only(top: 20),
                      color: AppColors.backGroundColor,
                      child: TabBar(
                        tabAlignment: TabAlignment.start,
                        overlayColor: MaterialStateProperty.all(Colors.transparent),
                        automaticIndicatorColorAdjustment: true,
                        dividerColor: AppColors.backGroundColor,
                        unselectedLabelColor: AppColors.unSelectedtabsColor,
                        labelColor: AppColors.whiteColor,
                        labelPadding: EdgeInsets.only(left: 15),
                        isScrollable: true,
                        physics: BouncingScrollPhysics(),

                        indicator: BoxDecoration(
                          borderRadius: BorderRadius.circular(32),
                          border: Border.all(color: AppColors.primaryColor),
                        ),
                        controller: tabController,
                        tabs: int.parse(controller.facultyCourse["labCredits"]) <= 0 ? [
                          _buildTab('CDF'), // New tab for CDF
                          _buildTab('Assignments'),
                          _buildTab('Quizzes'),
                          _buildTab('Midterm'),
                          _buildTab('Final'),
                        ] : [
                          _buildTab('CDF'), // New tab for CDF
                          _buildTab('Assignments'),
                          _buildTab('Lab Assignments'),
                          _buildTab('Quizzes'),
                          _buildTab('Midterm'),
                          _buildTab('Lab Midterm'),
                          _buildTab('Lab Final'),
                          _buildTab('Final'),
                        ],
                      ),
                    ),
                    Spacer(),
                    Padding(
                      padding: const EdgeInsets.only(top: 20, right: 27),
                      child: CustomButton(
                        text: 'Submit',
                        height: height * 0.05,
                        width: width * 0.06,
                        textStyle: CustomTextStyles.l24_white,
                        borderRadius: 35,
                        color: AppColors.primaryColor,
                      ),
                    ),
                  ],
                ),
              ),
              Flexible(
                child: TabBarView(
                  controller: tabController,
                  children: int.parse(controller.facultyCourse["labCredits"]) <= 0 ?[
                    FacultyMemberCDFScreen(), // Screen for CDF
                    FacultyMemberAssignmentsScreen(), // Screen for Assignments
                    FacultyMemberQuizzesScreen(), // Screen for Quizzes
                    FacultyMemberMidtermScreen(), // Screen for Midterm
                    FacultyMemberFinalScreen(), // Screen for Final
                  ]:[
                    FacultyMemberCDFScreen(), // Screen for CDF
                    FacultyMemberAssignmentsScreen(), // Screen for Assignments
                    LabAssignments(), // Screen for Lab Assignments
                    FacultyMemberQuizzesScreen(), // Screen for Quizzes
                    FacultyMemberMidtermScreen(), // Screen for Midterm
                    LabMidterm(), // Screen for Lab Midterm
                    LabFinals(), // Screen for Lab Final
                    FacultyMemberFinalScreen(), // Screen for Final
                  ]
                  ,
                ),
              ),
            ],
          ),
        );
      }
    );
  }

  Widget _buildTab(String label) {
    return Container(
      height: 35,
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(35)),
      child: Tab(
        child: Center(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 15.0),
            child: Text(label, style: CustomTextStyles.l24_black),
          ),
        ),
      ),
    );
  }
}
