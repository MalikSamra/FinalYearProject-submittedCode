import 'dart:html' as html;
import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:fypp/utils/appColors.dart';
import 'package:get/get.dart';

import '../../../controllers/user_controller.dart';

class FacultyMemberCDFScreen extends StatefulWidget {
  const FacultyMemberCDFScreen({Key? key}) : super(key: key);

  @override
  State<FacultyMemberCDFScreen> createState() => _FacultyMemberCDFScreenState();
}

class _FacultyMemberCDFScreenState extends State<FacultyMemberCDFScreen> {
  // List to store uploaded file metadata from Firestore
  List<Map<String, dynamic>> uploadedFiles = [];
  var userController = Get.find<UserController>();

  @override
  void initState() {
    super.initState();
    // Load existing files from Firestore when the widget initializes
    _loadUploadedFiles();
  }

  // Method to load uploaded files from Firestore
  Future<void> _loadUploadedFiles() async {
    QuerySnapshot querySnapshot =
        await FirebaseFirestore.instance.collection('uploaded_files').doc(userController.userModal!.uid).collection("cdf").get();

    setState(() {
      uploadedFiles = querySnapshot.docs
          .map((doc) => doc.data() as Map<String, dynamic>)
          .toList();
    });
  }

  // Callback for when a file is uploaded
  void _onFileUploaded(Map<String, dynamic> fileData) {
    setState(() {
      uploadedFiles.add(fileData);
    });
  }

  // Callback for when a file is deleted
  void _onFileDeleted(String fileUrl) {
    setState(() {
      uploadedFiles.removeWhere((file) => file['url'] == fileUrl);
    });
  }

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    return Container(
      color: AppColors.backGroundColor,
      padding: EdgeInsets.only(top: 50, right: 25, left: 25),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Upload Course Description File (CDF)',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            SizedBox(height: height * 0.03),
            CDFContainer(
              height: height,
              text: 'CDF File',
              onFileUploaded: _onFileUploaded,
              onFileDeleted: _onFileDeleted,
              uploadedFiles: uploadedFiles,
            ),
            SizedBox(height: 20),
           /* GestureDetector(
              onTap: () {
                setState(() {
                  uploadedFiles.add({});
                });
              },
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(35),
                  border: Border.all(color: AppColors.primaryColor),
                ),
                padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Add Additional CDF File'),
                    Icon(
                      Icons.add,
                      size: 30,
                      color: AppColors.primaryColor,
                    ),
                  ],
                ),
              ),
            ),*/
            SizedBox(height: 60),
          ],
        ),
      ),
    );
  }
}

class CDFContainer extends StatefulWidget {
  CDFContainer({
    super.key,
    required this.height,
    required this.text,
    required this.onFileUploaded,
    required this.onFileDeleted,
    required this.uploadedFiles,
  });

  final double height;
  final String text;
  final void Function(Map<String, dynamic> fileData) onFileUploaded;
  final void Function(String fileUrl) onFileDeleted;
  final List<Map<String, dynamic>> uploadedFiles;

  @override
  State<CDFContainer> createState() => _CDFContainerState();
}

class _CDFContainerState extends State<CDFContainer> {
  String? _fileName;
  Uint8List? _fileBytes;
  String? _fileUrl;
  int uploadedCount = 0;

  var userController = Get.find<UserController>();
bool _loading = false;

  Map<String,dynamic> fileDataLoad = {};
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getFileData();
  }
  void getFileData() async {
    setState(() {
      _loading = true;
    });
    var snapshot = await FirebaseFirestore.instance.collection('uploaded_files').doc("${userController.userModal!.uid}_${userController.facultySelectedCourse}").collection("cdf").get();
    await FirebaseFirestore.instance
        .collection('progress').doc("${userController.userModal!.uid}_${userController.facultySelectedCourse}").collection(userController.facultySelectedCourse).doc("progress").get().then((value) {
      uploadedCount = value.data()!.isEmpty ? 0 : value.data()!['uploadedCount'];

    });
    if(snapshot.docs.isNotEmpty && snapshot.docs.first.data()["title"] == widget.text.toLowerCase().replaceAll(" ", "_")){
      setState(() {
        fileDataLoad = snapshot.docs.isEmpty ? {} : snapshot.docs.first.data();
        _fileUrl = fileDataLoad['url'];
      });
    }
    setState(() {
      _loading = false;
    });
  }

  // Method to upload file to Firebase Storage
  Future<void> _uploadFileToFirebase() async {
    if (_fileBytes != null) {
      EasyLoading.show(status: 'Uploading file...');
      final storageRef =
          FirebaseStorage.instance.ref().child('uploads/$_fileName');

      try {
        final uploadTask = storageRef.putData(_fileBytes!);
        final snapshot = await uploadTask.whenComplete(() {});

        final downloadUrl = await snapshot.ref.getDownloadURL();

        // Save the file metadata in Firestore
        final fileData = {
          'fileName': _fileName,
          'url': downloadUrl,
          'uploadedAt': Timestamp.now(),
          'isChecked': false,
        };

        await FirebaseFirestore.instance
            .collection('uploaded_files').doc("${userController.userModal!.uid}_${userController.facultySelectedCourse}").collection('cdf')
            .add(fileData);
        await FirebaseFirestore.instance
            .collection('progress').doc("${userController.userModal!.uid}_${userController.facultySelectedCourse}").collection(userController.facultySelectedCourse).doc("progress").update(
            {
              "uploadedCount": uploadedCount + 1,
            }
        );
        setState(() {
          _fileUrl = downloadUrl;
        });
        await FirebaseFirestore.instance
            .collection('progress').doc("${userController.userModal!.uid}_${userController.facultySelectedCourse}").collection(userController.facultySelectedCourse).doc("progress").update(
            {
              "uploadedCount": uploadedCount + 1,
            }
        );
        // Pass the file data to the parent widget
        widget.onFileUploaded(fileData);
        EasyLoading.showSuccess('File uploaded successfully');
        EasyLoading.dismiss();

      } catch (e) {
        print('Error uploading file: $e');
        EasyLoading.showError('Error uploading file');
        EasyLoading.dismiss();
      }
    }
  }

  Future<void> _pickFile() async {
    html.FileUploadInputElement uploadInput = html.FileUploadInputElement();
    uploadInput.accept = 'image/*,application/pdf';
    uploadInput.multiple = false;
    uploadInput.click();

    uploadInput.onChange.listen((e) {
      final files = uploadInput.files;
      if (files != null && files.isNotEmpty) {
        final file = files[0];
        final reader = html.FileReader();

        reader.onLoadEnd.listen((e) {
          setState(() {
            _fileName = file.name;
            _fileBytes = reader.result as Uint8List;
          });

          // Upload the file to Firebase Storage
          _uploadFileToFirebase();
        });

        reader.readAsArrayBuffer(file);
      }
    });
  }

  Future<void> _deleteFile(String? url) async {
    if (url != null) {
      try {
        EasyLoading.show(status: 'removing file...');
        // Get the file reference from its URL
        final ref = FirebaseStorage.instance.refFromURL(url);

        // Delete the file from Firebase Storage
        await ref.delete();

        // Delete the file metadata from Firestore
        final querySnapshot = await FirebaseFirestore.instance
            .collection('uploaded_files').doc("${userController.userModal!.uid}_${userController.facultySelectedCourse}").collection('cdf')
            .where('url', isEqualTo: url)
            .get();

        if (querySnapshot.docs.isNotEmpty) {
          await querySnapshot.docs.first.reference.delete();
        }

        // Update the UI to reflect the deletion
        setState(() {
          _fileUrl = null;
          widget.onFileDeleted(url);
        });
        await FirebaseFirestore.instance
            .collection('progress').doc("${userController.userModal!.uid}_${userController.facultySelectedCourse}").collection(userController.facultySelectedCourse).doc("progress").set(
            {
              "uploadedCount": uploadedCount - 1,
            }
        );

        EasyLoading.showSuccess('File removed successfully');
        EasyLoading.dismiss();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('File deleted successfully!')),
        );
      } catch (e) {
        EasyLoading.showError('Error');
        EasyLoading.dismiss();
        print('Error deleting file: $e');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to delete file: $e')),
        );
      }
    }
  }

  void _handleFileClick(String? url) {
    if (url != null) {
      html.window.open(url, '_blank');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(widget.text,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          SizedBox(height: widget.height * 0.01),
          Container(
            color: AppColors.d9d9d9,
            padding: EdgeInsets.symmetric(
              vertical: widget.height * 0.023,
              horizontal: widget.height * 0.020,
            ),
            child: widget.uploadedFiles.isEmpty
                ? Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(),
                      CustomContainerRounded(
                        color: AppColors.e7e7e7,
                        text: 'Upload CDF',
                        onTap: _pickFile,
                      ),
                      Column(
                        children: [
                          Icon(Icons.edit),
                          SizedBox(height: widget.height * 0.005),
                          Icon(Icons.close),
                        ],
                      ),
                    ],
                  )
                : ListView.builder(
                    shrinkWrap: true,
                    itemCount: widget.uploadedFiles.length,
                    itemBuilder: (context, index) {
                      final file = widget.uploadedFiles[index];
                      return GestureDetector(
                        onTap: () => _handleFileClick(file['url']),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(file['fileName'] ?? 'File selected'),
                            Row(
                              children: [
                                IconButton(
                                  icon: Icon(Icons.edit),
                                  onPressed: _pickFile,
                                ),
                                IconButton(
                                  icon: Icon(Icons.close),
                                  onPressed: () => _deleteFile(file['url']),
                                ),
                              ],
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  bool _isImage(String path) {
    final extension = path.split('.').last.toLowerCase();
    return ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].contains(extension);
  }
}

class CustomContainerRounded extends StatelessWidget {
  const CustomContainerRounded({
    Key? key,
    required this.color,
    required this.text,
    this.onTap,
  }) : super(key: key);

  final Color color;
  final String text;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(20),
        ),
        padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
        child: Text(
          text,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}
