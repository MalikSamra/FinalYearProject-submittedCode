import 'dart:convert'; // For Base64 encoding
import 'dart:html' as html; // For web file handling
import 'dart:typed_data'; // For handling file data

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:fypp/services/api_services.dart';
import 'package:fypp/utils/appColors.dart';
import 'package:get/get.dart';

import '../../../controllers/user_controller.dart';
import '../../../services/predictionServer.dart';

class FacultyMemberAssignmentsScreen extends StatefulWidget {
  const FacultyMemberAssignmentsScreen({Key? key}) : super(key: key);

  @override
  State<FacultyMemberAssignmentsScreen> createState() =>
      _FacultyMemberAssignmentsScreenState();
}

class _FacultyMemberAssignmentsScreenState
    extends State<FacultyMemberAssignmentsScreen> {
  List<int> _expansionTileIndices = List.generate(4, (index) => index);

  void _addExpansionTile() {
    setState(() {
      _expansionTileIndices.add(_expansionTileIndices.length);
    });
  }

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    return Container(
      color: AppColors.backGroundColor,
      padding: EdgeInsets.only(top: 50, right: 25, left: 25),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            for (var index in _expansionTileIndices)
              Column(
                children: [
                  SizedBox(height: height * 0.1),
                  StreamBuilder(
                    stream: FirebaseFirestore.instance.collection('uploaded_files').doc(Get.find<UserController>().userModal!.uid).collection('assignment_number_${index + 1}').snapshots(),
                    builder: (context, snapshot) {
                      if(snapshot.connectionState == ConnectionState.waiting){
                        return Center(child: CircularProgressIndicator(

                        ));
                      }
                      return  ExpansionTile(
                        title: Text('Assignment Number ${index + 1}'),
                        children: [
                          AssignmentsContainer(
                            height: height,
                            title: "Assignment Number ${index + 1}",
                            text: 'Assignment Question',
                          ),
                          AssignmentsContainer(
                            height: height,
                            title: "Assignment Number ${index + 1}",
                            text: 'Solution',
                          ),
                          AssignmentsContainer(
                            height: height,
                            title: "Assignment Number ${index + 1}",
                            text: 'Best Sample',
                          ),
                          AssignmentsContainer(
                            height: height,
                            title: "Assignment Number ${index + 1}",
                            text: 'Average Sample',
                          ),
                          AssignmentsContainer(
                            height: height,
                            title: "Assignment Number ${index + 1}",
                            text: 'Worst Sample',
                          ),
                        ],
                      );
                    }
                  ),
                ],
              ),
            SizedBox(height: height * 0.1),
           /* GestureDetector(
              onTap: _addExpansionTile,
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(35),
                  border: Border.all(color: AppColors.primaryColor),
                ),
                padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Additional Assignments'),
                    Icon(
                      Icons.add,
                      size: 30,
                      color: AppColors.primaryColor,
                    )
                  ],
                ),
              ),
            ),
            SizedBox(height: 60),*/
          ],
        ),
      ),
    );
  }
}

class AssignmentsContainer extends StatefulWidget {
  AssignmentsContainer({super.key, required this.height, required this.text, required this.title, this.fileUrlIfApplicable = ""});

  final double height;
  final String text;
  final String title;
  String fileUrlIfApplicable;

  @override
  State<AssignmentsContainer> createState() => _AssignmentsContainerState();
}

class _AssignmentsContainerState extends State<AssignmentsContainer> {
  String? _fileName;
  Uint8List? _fileBytes; // To hold file data in bytes
  String? _fileUrl; // For displaying image or other files
  var userController = Get.find<UserController>();
  bool _loading = false;
  int uploadedCount = 0;

  Map<String,dynamic> fileDataLoad = {};
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getFileData();
  }
  void getFileData() async {
    setState(() {
      _loading = true;
    });
    var snapshot = await FirebaseFirestore.instance.collection('uploaded_files').doc("${userController.userModal!.uid}_${userController.facultySelectedCourse}").collection(widget.title.toLowerCase().replaceAll(" ", "_")).get();
    await FirebaseFirestore.instance
        .collection('progress').doc("${userController.userModal!.uid}_${userController.facultySelectedCourse}").collection(userController.facultySelectedCourse).doc("progress").get().then((value) {
      uploadedCount = !value.exists ? 0 : value.data()!['uploadedCount'];

    });
    if(snapshot.docs.isNotEmpty && snapshot.docs.first.data()["title"] == widget.text.toLowerCase().replaceAll(" ", "_")){
      setState(() {
        fileDataLoad = snapshot.docs.isEmpty ? {} : snapshot.docs.first.data();
      });
    }
    setState(() {
      _loading = false;
    });
  }
  // Method to upload file to Firebase Storage
  Future<void> _uploadFileToFirebase() async {

    if (_fileBytes != null) {
      EasyLoading.show(status: 'Uploading file...');
      final storageRef =
      FirebaseStorage.instance.ref().child('uploads/$_fileName');

      try {
        final uploadTask = storageRef.putData(_fileBytes!);
        final snapshot = await uploadTask.whenComplete(() {});

        final downloadUrl = await snapshot.ref.getDownloadURL();

        // Save the file metadata in Firestore
        final fileData = {
          'fileName': _fileName,
          'url': downloadUrl,
          "title": widget.text.toLowerCase().replaceAll(" ", "_"),
          'uploadedAt': Timestamp.now(),
          'isChecked': false,
        };

        await FirebaseFirestore.instance
            .collection('uploaded_files').doc("${userController.userModal!.uid}_${userController.facultySelectedCourse}").collection(widget.title.toLowerCase().replaceAll(" ", "_"))
            .add(fileData);
        await FirebaseFirestore.instance
            .collection('progress').doc("${userController.userModal!.uid}_${userController.facultySelectedCourse}").collection(userController.facultySelectedCourse).doc("progress").set(
            {
              "uploadedCount": uploadedCount + 1,
            }
        );
        // Pass the file data to the parent widge
        EasyLoading.showSuccess('File uploaded successfully');
        EasyLoading.dismiss();

        setState(() {
          _fileUrl = downloadUrl;
          fileDataLoad = fileData;
        });

      } catch (e) {
        print('Error uploading file: $e');
        EasyLoading.showError('Error uploading file');
        EasyLoading.dismiss();
      }
    }
  }

  Future<void> _pickFile() async {
    html.FileUploadInputElement uploadInput = html.FileUploadInputElement();
    uploadInput.accept = 'image/*,application/pdf';
    uploadInput.multiple = false;
    uploadInput.click();

    uploadInput.onChange.listen((e) {
      final files = uploadInput.files;
      if (files != null && files.isNotEmpty) {
        final file = files[0];
        final reader = html.FileReader();

        reader.onLoadEnd.listen((e) async{
          setState(() {
            _fileName = file.name;
            _fileBytes = reader.result as Uint8List;
          });
          EasyLoading.show(status: 'Checking file type...');
          var data = await PredictionService(ApiService.baseURl).predict(
            fileData: _fileBytes,
            fileName: _fileName,
          );
          if(data["class"] == "Assignment_images"){
            EasyLoading.dismiss();
            _uploadFileToFirebase();
          }else{
            EasyLoading.showError('Invalid file type');
            EasyLoading.dismiss();
          }
          // Upload the file to Firebase Storage
        });

        reader.readAsArrayBuffer(file);
      }
    });
  }

  Future<void> _deleteFile(String? url) async {
    if (url != null) {
      try {
        EasyLoading.show(status: 'removing file...');
        // Get the file reference from its URL
        final ref = FirebaseStorage.instance.refFromURL(url);

        // Delete the file from Firebase Storage
        await ref.delete();

        // Delete the file metadata from Firestore
        final querySnapshot = await FirebaseFirestore.instance
            .collection('uploaded_files').doc("${userController.userModal!.uid}_${userController.facultySelectedCourse}").collection(widget.text.toLowerCase().replaceAll(" ", "_"))
            .where('url', isEqualTo: url)
            .get();

        if (querySnapshot.docs.isNotEmpty) {
          await querySnapshot.docs.first.reference.delete();
        }

        // Update the UI to reflect the deletion
        setState(() {
          _fileUrl = null;

        });
        await FirebaseFirestore.instance
            .collection('progress').doc("${userController.userModal!.uid}_${userController.facultySelectedCourse}").collection(userController.facultySelectedCourse).doc("progress").update(
            {
              "uploadedCount": uploadedCount - 1,
            }
        );
        EasyLoading.showSuccess('File removed successfully');
        EasyLoading.dismiss();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('File deleted successfully!')),
        );
      } catch (e) {
        EasyLoading.showError('Error');
        EasyLoading.dismiss();
        print('Error deleting file: $e');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to delete file: $e')),
        );
      }
    }
  }

  void _handleFileClick(String? url) {
    if (url != null) {
      html.window.open(url, '_blank');
    }
  }


  bool _isImage(String path) {
    final extension = path.split('.').last.toLowerCase();
    return ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].contains(extension);
  }

  @override
  Widget build(BuildContext context) {
    return _loading ? Center(
      child: CircularProgressIndicator(),
    ) : Padding(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(widget.text,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          SizedBox(height: widget.height * 0.01),
          Container(
            color: AppColors.d9d9d9,
            padding: EdgeInsets.symmetric(
              vertical: widget.height * 0.023,
              horizontal: widget.height * 0.020,
            ),
            child: fileDataLoad != {} ?
            GestureDetector(
              onTap: () => _handleFileClick(fileDataLoad['url']),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(fileDataLoad['fileName'] ?? 'File selected'),
                  Row(
                    children: [
                      IconButton(
                        icon: Icon(Icons.edit),
                        onPressed: (){
                          _deleteFile(fileDataLoad['url']);
                          _pickFile();
                        },
                      ),
                      IconButton(
                        icon: Icon(Icons.close),
                        onPressed: () => _deleteFile(fileDataLoad['url']),
                      ),
                    ],
                  ),
                ],
              ),
            )
                : _fileBytes == null
                ? Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(),
                      CustomContainerRounded(
                        color: AppColors.e7e7e7,
                        text: 'Upload File',
                        onTap: _pickFile, // Trigger file picking
                      ),
                      Column(
                        children: [
                          Icon(Icons.edit),
                          SizedBox(height: widget.height * 0.005),
                          Icon(Icons.close),
                        ],
                      ),
                    ],
                  )
                : GestureDetector(
                    onTap:
                        () {
                          _handleFileClick(_fileUrl);
                        }, // Handle file click to view or download
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _fileUrl != null && _isImage(_fileName!)
                            ? Image.network(_fileUrl!, width: 100, height: 100)
                            : Text(_fileName ?? 'File selected'),
                        Row(
                          children: [
                            IconButton(
                              icon: Icon(Icons.edit),
                              onPressed: _pickFile, // Edit file
                            ),
                            IconButton(
                              icon: Icon(Icons.close),
                              onPressed: () {
                                setState(() {
                                  _fileName = null;
                                  _fileBytes = null;
                                  _fileUrl = null;
                                });
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

class CustomContainerRounded extends StatelessWidget {
  const CustomContainerRounded({
    Key? key,
    required this.color,
    required this.text,
    this.onTap,
  }) : super(key: key);

  final Color color;
  final String text;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(20),
        ),
        padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
        child: Text(
          text,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}
