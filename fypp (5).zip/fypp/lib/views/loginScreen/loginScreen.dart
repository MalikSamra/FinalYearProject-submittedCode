import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:fypp/services/api_services.dart';
import 'package:fypp/services/auth-services.dart';
import 'package:fypp/utils/appColors.dart';
import 'package:fypp/utils/constants.dart';
import 'package:fypp/widgets/customDropDown.dart';
import 'package:get/get.dart';

import '../../utils/CustomTextStyles.dart';
import '../administrativeConsole/administrativeConsole.dart';
import '../facultyMemberConsole/facultyMemberConsole.dart';
import '../qecConverConsole/qecConverConsole.dart';
import '../qecMemberConsole/qecMemberConsole.dart';

class LoginScreen extends StatefulWidget {
  final String? text;
  bool fromAdmin = false;
  final bool showLogin;

  LoginScreen({Key? key, this.text, this.showLogin = true, this.fromAdmin = false}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  late bool showLogin;
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _confirmPasswordControllerS = TextEditingController();
  final TextEditingController _passwordControllerS = TextEditingController();
  final TextEditingController _usernameControllerS = TextEditingController();
  final TextEditingController _emailControllerS = TextEditingController();
  bool _passShow = false;
  bool _passShowS = false;
  bool _cPassShowS = false;
  String selectedRole = '';
  @override
  void initState() {
    super.initState();
    showLogin = widget.showLogin;
  }

  String getConsoleName() {
    switch (widget.text) {
      case 'administrative':
        return 'Administrative Console';
      case 'qecconver':
        return 'QEC Convenor Console';
      case 'qecmemberconsole':
        return 'QEC Member Console';
      case 'facultymember':
        return 'Faculty Console';
      default:
        return '';
    }
  }

  void navigateToConsole() {
    switch (widget.text) {
      case 'administrative':
        Get.to(() => AdministrativeConsole());
        break;
      case 'qecconver':
        Get.to(() => QecConverConsole());
        break;
      case 'qecmemberconsole':
        Get.to(() => QecMemberConsole());
        break;
      case 'facultymember':
        Get.to(() => FacultyMemberConsole());
        break;
      default:
        Get.to(() => FacultyMemberConsole()); // Default navigation
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: AppColors.primaryColor,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 55, vertical: 22),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              children: [
                Row(
                  children: [
                    Container(
                      width: width * 0.23,
                      child: Text(
                        getConsoleName(),
                        style: CustomTextStyles.l28_400_white,
                        textAlign: TextAlign.start,
                        maxLines: 4,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(width: width * 0.03),
            Expanded(
              child: SingleChildScrollView(
                child: Stack(
                  children: [
                    // Login Container
                    Visibility(
                      visible: showLogin,
                      child: buildLoginContainer(height, width),
                    ),
                    // Signup Container
                    Visibility(
                      visible: !showLogin || widget.fromAdmin,
                      child: buildSignupContainer(height, width),
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget buildLoginContainer(double height, double width) {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Login',
            style: TextStyle(
              fontSize: 20,
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: height * 0.01),
          Container(
            padding: EdgeInsets.only(top: 40, left: 30, right: 30),
            decoration: BoxDecoration(
              color: AppColors.whiteColor,
              borderRadius: BorderRadius.circular(24),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Login with your authentic Information',
                  style: CustomTextStyles.l32_black,
                  textAlign: TextAlign.start,
                ),
                SizedBox(height: height * 0.02),
                Text(
                  'Enter your email',
                  style: CustomTextStyles.l24_black,
                  textAlign: TextAlign.start,
                ),
                SizedBox(height: height * 0.01),
                TextFormField(
                  controller: _emailController,
                  decoration: InputDecoration(
                    hintText: 'user@gmail.com',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
                SizedBox(height: height * 0.02),
                Text(
                  'Enter your Password',
                  style: CustomTextStyles.l24_black,
                  textAlign: TextAlign.start,
                ),
                SizedBox(height: height * 0.01),
                TextFormField(
                  controller: _passwordController,
                  decoration: InputDecoration(
                    hintText: '********',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    suffixIcon: InkWell(onTap: (){
                      setState(() {
                        _passShow = !_passShow;
                      });
                    }, child: Icon(_passShow ? Icons.visibility_off : Icons.visibility)),
                  ),
                  obscureText: _passShow,
                ),
                SizedBox(height: height * 0.034),
                Center(
                  child: ElevatedButton(
                    onPressed: ()async{

                      final apiService = AuthService();
                      if(_emailController.text.isNotEmpty && _passwordController.text.isNotEmpty){
                        EasyLoading.show(status: 'Logging in...');
                        var user = await apiService.signInWithEmail(_emailController.text, _passwordController.text);
                        if(user != null) {
                          EasyLoading.dismiss();
                          if(user.contains(widget.text.toString())){
                            navigateToConsole();
                          }else{
                            Get.showSnackbar(GetSnackBar(
                              message: 'Invalid User',
                              duration: Duration(seconds: 2),
                            ));
                            Navigator.pop(context);
                          }

                        }
                      }else{
                        Get.showSnackbar(GetSnackBar(
                          message: 'Please fill all the fields',
                          duration: Duration(seconds: 2),
                        ));
                      }
                    },
                    child: Text('Login'),
                  ),
                ),
                SizedBox(height: height * 0.02),
               widget.text == "administrative" ? Center(
                  child: TextButton(
                    onPressed: () {
                      setState(() {
                        showLogin = false; // Show Signup container
                      });
                    },
                    child: Text('Don\'t have an account? Sign Up'),
                  ),
                ) : SizedBox(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget buildSignupContainer(double height, double width) {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
           widget.fromAdmin ? "Add Member" : 'Signup',
            style: TextStyle(
              fontSize: 20,
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: height * 0.01),
          Container(
            padding: EdgeInsets.only(top: 40, left: 30, right: 30),
            decoration: BoxDecoration(
              color: AppColors.whiteColor,
              borderRadius: BorderRadius.circular(24),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                 widget.fromAdmin ? 'Add member details' : 'Signup with your details',
                  style: CustomTextStyles.l32_black,
                  textAlign: TextAlign.start,
                ),
                SizedBox(height: height * 0.02),
                Text(
                  'Enter your Username',
                  style: CustomTextStyles.l24_black,
                  textAlign: TextAlign.start,
                ),
                SizedBox(height: height * 0.01),
                TextFormField(
                  controller: _usernameControllerS,
                  decoration: InputDecoration(
                    hintText: 'Username',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
                SizedBox(height: height * 0.02),
                Text(
                  'Enter your email',
                  style: CustomTextStyles.l24_black,
                  textAlign: TextAlign.start,
                ),
                SizedBox(height: height * 0.01),
                TextFormField(
                  controller: _emailControllerS,
                  decoration: InputDecoration(
                    hintText: 'user@gmail.com',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
                SizedBox(height: height * 0.02),
                Text(
                  'Enter your Password',
                  style: CustomTextStyles.l24_black,
                  textAlign: TextAlign.start,
                ),
                SizedBox(height: height * 0.01),
                TextFormField(
                  controller: _passwordControllerS,
                  decoration: InputDecoration(
                    hintText: '********',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    suffixIcon: InkWell(onTap: (){
                      setState(() {
                        _passShowS = !_passShowS;
                      });
                    }, child:  Icon(_passShowS ? Icons.visibility_off : Icons.visibility)),
                  ),
                  obscureText: _passShowS,
                ),
                SizedBox(height: height * 0.034),
                Text(
                  'Confirm your Password',
                  style: CustomTextStyles.l24_black,
                  textAlign: TextAlign.start,
                ),
                SizedBox(height: height * 0.01),
                TextFormField(
                  controller: _confirmPasswordControllerS,
                  decoration: InputDecoration(
                    hintText: '********',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    suffixIcon:  InkWell (
                        onTap: (){
                          setState(() {
                            _cPassShowS = !_cPassShowS;
                          });
                        },
                        child: Icon(_cPassShowS ? Icons.visibility_off : Icons.visibility)),
                  ),
                  obscureText: _cPassShowS,
                ),
                widget.fromAdmin ? SizedBox(height: height * 0.01): SizedBox(),
                widget.fromAdmin ? SizedBox():SizedBox(height: height * 0.02),
                !widget.fromAdmin ? SizedBox(): Text(
                  'Select Role',
                  style: CustomTextStyles.l24_black,
                  textAlign: TextAlign.start,
                ),
               !widget.fromAdmin ? SizedBox() : SizedBox(height: height * 0.01),
                widget.fromAdmin ? Column(
                  children: [
                    CheckboxListTile(
                      title: Text("QEC Convenor"),
                      value: selectedRole.contains(Constants.getConsoleName("QEC Convenor")),
                      onChanged: (bool? value) {
                        setState(() {
                          if (value == true) {
                            selectedRole += "${Constants.getConsoleName("QEC Convenor")} ";
                          } else {
                            selectedRole = selectedRole.replaceAll("${Constants.getConsoleName("QEC Convenor")} ", "");
                          }
                        });
                      },
                    ),
                    CheckboxListTile(
                      title: Text("QEC Member"),
                      value: selectedRole.contains(Constants.getConsoleName("QEC Member")),
                      onChanged: (bool? value) {
                        setState(() {
                          if (value == true) {
                            selectedRole += "${Constants.getConsoleName("QEC Member")} ";
                          } else {
                            selectedRole = selectedRole.replaceAll(Constants.getConsoleName("QEC Member")+ " ", "");
                          }
                        });
                      },
                    ),
                    CheckboxListTile(
                      title: Text("Faculty Member"),
                      value: selectedRole.contains(Constants.getConsoleName("Faculty Member")),
                      onChanged: (bool? value) {
                        setState(() {
                          if (value == true) {
                            selectedRole += "${Constants.getConsoleName("Faculty Member")} ";
                          } else {
                            selectedRole = selectedRole.replaceAll("${Constants.getConsoleName("Faculty Member")} ", "");
                          }
                        });
                      },
                    ),
                  ],
                ) : SizedBox(),
                SizedBox(height: height * 0.034),
                Center(
                  child: ElevatedButton(
                    onPressed:widget.fromAdmin ? ()async{
                      if((_passwordControllerS.text == _confirmPasswordControllerS.text) && _passwordControllerS.text.isNotEmpty && _emailControllerS.text.isNotEmpty && _usernameControllerS.text.isNotEmpty && selectedRole.isNotEmpty){
                        EasyLoading.show(status: 'Creating User...');
                        try{
                                var auth = await FirebaseAuth.instance
                                    .createUserWithEmailAndPassword(
                                        email: _emailControllerS.text,
                                        password:
                                            _confirmPasswordControllerS.text);
                                if (auth != null) {
                                  await FirebaseFirestore.instance
                                      .collection('users')
                                      .doc(auth.user!.uid)
                                      .set({
                                    'email': _emailControllerS.text,
                                    'username': _usernameControllerS.text,
                                    'userType': selectedRole,
                                    'uid': auth.user!.uid,
                                  });
                                  EasyLoading.dismiss();
                                  Get.showSnackbar(GetBar(
                                    message: 'User Created Successfully',
                                    backgroundColor: Colors.deepPurple,
                                    duration: Duration(seconds: 2),
                                  ));
                                  _usernameControllerS.clear();
                                  _emailControllerS.clear();
                                  _passwordControllerS.clear();
                                  _confirmPasswordControllerS.clear();
                                  selectedRole = '';
                                }
                              }on FirebaseException catch(e){
                                EasyLoading.dismiss();
                                Get.showSnackbar(GetBar(
                                  message: e.message!,
                                  backgroundColor: Colors.red,
                                  duration: Duration(seconds: 2),
                                ));
                              }
                            }else{
                              Get.showSnackbar(GetBar(
                                message: 'Please fill all the fields',
                                duration: Duration(seconds: 2),
                              ));
                      }
                    } : ()async{
                      final apiService = AuthService();
                      if((_passwordControllerS.text == _confirmPasswordControllerS.text) && _passwordControllerS.text.isNotEmpty && _emailControllerS.text.isNotEmpty && _usernameControllerS.text.isNotEmpty){
                        EasyLoading.show(status: 'Signing up...');
                        var user = await apiService.signUpWithEmail(_emailControllerS.text, _passwordControllerS.text, _usernameControllerS.text, widget.text!);
                        if(user != null) {
                          EasyLoading.dismiss();
                          navigateToConsole();
                        }
                      }else{
                        Get.showSnackbar(GetBar(
                          message: 'Please fill all the fields',
                          duration: Duration(seconds: 2),
                        ));
                      }
                    },
                    child: widget.fromAdmin ? Text("Add Member") : Text('Sign Up'),
                  ),
                ),
               widget.fromAdmin ? SizedBox() : SizedBox(height: height * 0.02),
               widget.fromAdmin ? SizedBox(): Center(
                  child: TextButton(
                    onPressed: () {
                      setState(() {
                        showLogin = true; // Show Login container
                      });
                    },
                    child: Text('Already have an account? Login'),
                  ),
                ),
                SizedBox(height: height * 0.02)
              ],
            ),
          ),
        ],
      ),
    );
  }
}
