import 'package:flutter/material.dart';
import 'package:fypp/views/administrativeConsole/adminstrativeCommunicate/administrativeCommunicate.dart';
import 'package:fypp/views/administrativeConsole/settingscreen/settings_screen.dart'; // Import the Settings Screen
import 'package:fypp/views/loginScreen/loginScreen.dart';

import 'administrativeGeneral/administrativeGeneral.dart';
import 'administrativeHomeScreen/administrativeHomeScreen.dart';

class AdministrativeConsole extends StatefulWidget {
  const AdministrativeConsole({Key? key}) : super(key: key);

  @override
  State<AdministrativeConsole> createState() => _AdministrativeConsoleState();
}

class _AdministrativeConsoleState extends State<AdministrativeConsole>
    with TickerProviderStateMixin {
  TabController? _tabController;
  int _selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 5, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Administrative Console'),
      ),
      body: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 200, // Adjust width as needed
            child: ListView(
              children: [
                _buildVerticalTab('Home', 0),
                _buildVerticalTab('Communicate', 1),
                _buildVerticalTab('General', 2),
                _buildVerticalTab("Add Member", 3),
                _buildVerticalTab('Setting', 4),
              ],
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                AdministrativeHomeScreen(),
                Administrativecommunicate(), // Placeholder for Communicate
                AdministrativeGeneral(),
                LoginScreen(
                  fromAdmin: true,
                  showLogin: false,
                  text: "Add Member",
                ),
                SettingsScreen(), // Use the Settings Screen here
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVerticalTab(String label, int index) {
    return ListTile(
      title: Text(label),
      selected: _selectedIndex == index,
      onTap: () {
        setState(() {
          _selectedIndex = index;
        });
        _tabController!.animateTo(index);
      },
    );
  }
}
