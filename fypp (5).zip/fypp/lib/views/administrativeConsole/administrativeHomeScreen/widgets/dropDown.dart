import 'package:flutter/material.dart';

class DropDownField extends StatelessWidget {
  final String? text;
  final Color? color;
  final Color? textColor;
  final void Function(String?)? onChanged; // Adjusted callback type

  DropDownField(
      {Key? key, this.text, this.color, this.textColor, this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: color ?? Colors.grey,
        borderRadius: BorderRadius.circular(50),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 35),
        child: Center(
          child: DropdownButton<String>(
            value: text,
            icon: Icon(Icons.arrow_drop_down),
            iconSize: 24,
            elevation: 16,
            style: TextStyle(color: textColor ?? Colors.black),
            underline: Container(
              height: 0,
              color: Colors.transparent,
            ),
            onChanged: onChanged,
            // Pass the onChanged callback directly
            items: <String>['Class 1', 'Class 2', 'Class 3', 'Class 4']
                .map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }
}
