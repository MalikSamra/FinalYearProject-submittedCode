import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:excel/excel.dart' hide Border;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:fypp/assetsPath/assetsPath.dart';
import 'package:fypp/controllers/administrativeGeneralController/administrativeGeneralController.dart';
import 'package:fypp/utils/CustomTextStyles.dart';
import 'package:fypp/utils/appColors.dart';
import 'package:fypp/widgets/customButton.dart';
import 'package:get/get.dart';

import '../../../controllers/user_controller.dart';
import '../../../models/admonistrativeConsoleModel/administrativeConsoleModel.dart';
import '../../../widgets/customDropDown.dart';

class AdministrativeHomeScreen extends StatefulWidget {
  const AdministrativeHomeScreen({super.key});

  @override
  State<AdministrativeHomeScreen> createState() =>
      _AdministrativeHomeScreenState();
}

class _AdministrativeHomeScreenState extends State<AdministrativeHomeScreen> {
  CourseInformation courseInformation = CourseInformation();
  AdministrativeGeneralController administrativeGeneralController =
      Get.put(AdministrativeGeneralController());
  String id = '';
  var userController = Get.find<UserController>();
  QueryDocumentSnapshot<Object?>? selectedFac;

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    List<Map<String, dynamic>> uniqueCourses = [];
    var userController = Get.find<UserController>();
    RegExp regExp = RegExp(r"\((\d+),(\d+)\)");

    Future<void> pickAndExtractCourses() async {

      var ref = FirebaseFirestore.instance.collection('courses');
      try {
        // Pick an Excel file
        FilePickerResult? result = await FilePicker.platform.pickFiles(
          type: FileType.custom,
          allowedExtensions: ['xlsx'],
        );

        if (result != null) {
          EasyLoading.show(status: 'Extracting courses...');

          // Read the Excel file
          var bytes =result.files.single.bytes!;
          var excel = Excel.decodeBytes(bytes);

          // Filter sheets containing "AI", "CS", or "SE" in their names
          var filteredSheets = excel.tables.keys.where((sheetName) =>
          sheetName.contains('AI') || sheetName.contains('CS') || sheetName.contains('SE'));

          // Extract unique courses
          var courses = <String, Map<String, String>>{};
          for (var sheetName in filteredSheets) {
            var sheet = excel.tables[sheetName];
            if (sheet != null) {
              for (var row in sheet.rows.skip(1)) { // Skip header
                if (row.length >= 3) {

                  var courseCode = row[1]?.value.toString() ?? '';
                  var courseName = row[2]?.value.toString() ?? '';
                  var creditHours = row[3]?.value.toString() ?? '';
                  print('Course Code: $courseCode, Course Name: $courseName, Credit Hours: $creditHours');
                  Match? match = regExp.firstMatch(creditHours);

                  if (courseCode.isNotEmpty && courseName.isNotEmpty && creditHours.isNotEmpty) {
                    courses[courseCode] = {
                      'course_name': "$courseName",
                      'lab_credits': match!.group(2)!,
                      'theory_credits': match.group(1)!,
                      'course_code': courseCode,

                    };
                  }
                }
              }
            }
          }


          // Update state with the extracted courses
          setState(() {
            uniqueCourses = courses.values.toList();
          });
          EasyLoading.dismiss();
          EasyLoading.show(status: 'Saving courses...');
          for (var course in uniqueCourses) {
            await ref.doc(course['course_code']).set({
              'course_name': course['course_name'],
              'lab_credits': course['lab_credits'],
              'theory_credits': course['theory_credits'],
              'course_code': course['course_code'],
            });
          }
          EasyLoading.showSuccess("Courses extracted successfully");
          EasyLoading.dismiss();
        }

      } catch (e) {
        EasyLoading.showError('An error occurred while extracting courses');
        EasyLoading.dismiss();

        print('Error: $e');
      }
    }


    void asgCourse()async {
      var _selectedCourse = userController.course;
      var doc = await FirebaseFirestore.instance.collection("assignedCourses").get();
      print(doc.docs.length);
      var docs = doc.docs.where((element) => element['facId'] == id).toList();
      var data = docs.where((element) => element['courseCode'] == _selectedCourse['course_code']).toList();
      if(data.isNotEmpty){
        Get.snackbar('Error', 'Course already assigned');
        return;
      }
      print(id+ "id");
      FirebaseFirestore.instance.collection("assignedCourses").doc().set({
        'courseName': _selectedCourse['course_name'],
        'courseCode': _selectedCourse['course_code'],
        'labCredits': _selectedCourse['lab_credits'],
        'theoryCredits': _selectedCourse['theory_credits'],
        'facId': selectedFac!.id,
        'program': administrativeGeneralController.selectClass.value,
        'last_updated': Timestamp.now(),
      });
    }
    return Container(
      color: AppColors.lightBlue,
      padding: EdgeInsets.only(left: 20, right: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 18, right: 30),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                CustomButton(
                  height: height * 0.04,
                  width: width * 0.05,
                  text: 'Save',
                  onPressed: () {

                    if(userController.course.isEmpty || id.isEmpty){
                      Get.snackbar('Error', 'Please select course and teacher');
                      return;
                    }else{

                      asgCourse();
                      Get.snackbar('Successful', 'Data Saved Successfully');
                      userController.emptyCourse();
                      id = '';
                      userController.setSelectFacId('');
                      administrativeGeneralController.selectClass.value = '';
                      administrativeGeneralController.selectCoarseName.value = '';
                      administrativeGeneralController.teacherName.value = '';
                    }
                    // clear the selected course and teacher



                  },
                  color: AppColors.primaryColor,
                  textStyle: CustomTextStyles.l26_white,
                  borderRadius: 40,
                ),
              ],
            ),
          ),
          SizedBox(height: height * 0.02),
          Text(
            'Select Assigned Course information:',
            style: CustomTextStyles.l24_black,
            textAlign: TextAlign.start,
            maxLines: 3,
          ),
          SizedBox(height: height * 0.03),
          FutureBuilder(
            future: FirebaseFirestore.instance.collection('courses').get(),
            builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(child: CircularProgressIndicator());
              }
              if (snapshot.hasError) {
                return Center(child: Text('Error: ${snapshot.error}'));
              }
              var courses = snapshot.data!.docs;
              return Container(
                padding: EdgeInsets.only(top: 10, left: 14, right: 10, bottom: 10),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(35),
                    border: Border.all(color: AppColors.primaryColor, width: 1)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomDropDown(
                        hint: 'Program',
                        items: const [
                          "BS CS",
                          "BS AI",
                          "BS SE",
                        ],
                        onChangedValue: (value) {
                          setState(() {
                            administrativeGeneralController.selectClass.value =
                                value ?? '';
                          });
                        },
                        width: width * 0.2,
                        initialValue:
                            administrativeGeneralController.selectClass.value),
                    CustomDropDown(
                        hint: 'Course Name',
                        items: courses.map((course) => course['course_name'] as String).toList(),
                        onChangedValue: (value) {
                          print('Value: $value');
                          var selection = courses.firstWhere((course) => course['course_name'] == value);
                          userController.setCourse({

                              'course_name': selection['course_name'],
                              'course_code': selection['course_code'],
                              'lab_credits': selection['lab_credits'],
                              'theory_credits': selection['theory_credits'],
                            }
                          );
                          setState(() {

                            administrativeGeneralController.selectCoarseName.value =
                                value ?? '';
                          });
                        },
                        width: width * 0.2,
                        initialValue:
                            administrativeGeneralController.selectCoarseName.value),

                    InkWell(
                      onTap: (){
                        userController.emptyCourse();
                        administrativeGeneralController.selectClass.value = '';
                        administrativeGeneralController.selectCoarseName.value = '';
                        administrativeGeneralController.teacherName.value = '';
                      },
                      child: Image.asset(
                        '${Assets.imagesPath}${Assets.crossIcon}',
                        height: height * 0.03,
                        width: width * 0.03,
                      ),
                    )
                  ],
                ),
              );
            }
          ),
          Spacer(),
          Text(
            'Assigned To',
            style: CustomTextStyles.l24_black,
            textAlign: TextAlign.start,
            maxLines: 3,
          ),
          SizedBox(height: height * 0.02),
          FutureBuilder(
            future: FirebaseFirestore.instance.collection('users').get(),
            builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(child: CircularProgressIndicator());
              }
              if (snapshot.hasError) {
                return Center(child: Text('Error: ${snapshot.error}'));
              }
              var faculty = snapshot.data!.docs.where((user) => user['userType'].toString().contains("facultymember")).toList();
              return Container(
                padding: EdgeInsets.only(top: 10, left: 14, right: 10, bottom: 10),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(35),
                    border: Border.all(color: AppColors.primaryColor, width: 1)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomDropDown(
                        hint: 'Teacher Name',
                        items:
                          faculty.map((user) => user['username'] as String).toList(),
                        onChangedValue: (value) {
                          var selection = faculty.firstWhere((user) => user['username'] == value);
                          userController.setSelectFacId(selection.id);
                          setState(() {
                            selectedFac = selection;
                            id = selection.id;
                          });
                        },
                        width: width * 0.2,
                        initialValue:
                            id.isNotEmpty ? faculty.firstWhere((user) => user.id == id)['username'] : id),
                    SizedBox(width: width * 0.05),
                  ],
                ),
              );
            }
          ),
          Spacer(),
          Text(
            'Import Courses from Excel Sheet:',
            style: CustomTextStyles.l24_black,
            textAlign: TextAlign.start,
            maxLines: 3,
          ),
          SizedBox(height: height * 0.02),
          InkWell(
            onTap: pickAndExtractCourses,
            child: Container(
              padding: EdgeInsets.only(top: 10, left: 14, right: 10, bottom: 10),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(35),
                  border: Border.all(color: AppColors.primaryColor, width: 1)),
              child: Center(
                child: Text(
                  'Import Courses',
                  style: CustomTextStyles.l24_black,
                  textAlign: TextAlign.start,
                  maxLines: 3,
                ),
              )
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}
