import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  String _filePath = '';

  Future<void> _pickFile() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles();

      if (result != null && result.files.single.path != null) {
        setState(() {
          _filePath = result.files.single.path!; // Save the file path
        });
      } else {
        // Handle the case where the user cancels the file picker
        setState(() {
          _filePath = 'No file selected';
        });
      }
    } catch (e) {
      print('Error picking file: $e');
      setState(() {
        _filePath = 'Error selecting file';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('File Picker Example'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: _pickFile,
              child: const Text('Pick File'),
            ),
            const SizedBox(height: 20),
            // Display file path
            Text(
              _filePath.isNotEmpty
                  ? 'Selected File: $_filePath'
                  : 'No File Selected',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
