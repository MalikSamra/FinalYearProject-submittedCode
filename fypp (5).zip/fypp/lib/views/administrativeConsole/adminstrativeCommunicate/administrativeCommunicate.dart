import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:fypp/utils/constants.dart';
import 'package:fypp/views/administrativeConsole/adminstrativeCommunicate/communicate.dart';

class Administrativecommunicate extends StatefulWidget {
  const Administrativecommunicate({super.key});

  @override
  State<Administrativecommunicate> createState() => _AdministrativecommunicateState();
}

class _AdministrativecommunicateState extends State<Administrativecommunicate> {
  String selectedUserId = '';
  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      body: StreamBuilder(
        stream: FirebaseFirestore.instance.collection("users").snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
          if (snapshot.hasError) {
            return Center(
              child: Text('Error: ${snapshot.error}'),
            );
          }
          var users = snapshot.data!.docs.where((element) => element['userType'] != 'administrative').toList();

          return Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 200,
                child: ListView.builder(itemCount: users.length, shrinkWrap: true, itemBuilder: (context, index) {
                  return Card(
                    child: ListTile(
                      onTap: (){
                        setState(() {
                          selectedUserId = users[index].id;
                        });
                      },
                      title: Text(users[index]['username']),
                      subtitle: Text(Constants.getAbb(users[index]['userType'])),
                    ),
                  );
                },),
              ),
              Expanded(child: selectedUserId == '' ? Center(
                child: Text('Select a member to communicate'),
              ) : Communicate(userId: selectedUserId))
            ],
          );
        }
      ),
    );
  }
}
