import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fypp/controllers/administrativeGeneralController/administrativeGeneralController.dart';
import 'package:fypp/utils/CustomTextStyles.dart';
import 'package:fypp/utils/appColors.dart';
import 'package:fypp/views/administrativeConsole/administrativeGeneral/tabs/members_data.dart';
import 'package:fypp/widgets/customButton.dart';
import 'package:get/get.dart';

import '../../../controllers/administrativeGeneralController/widgets/administrativeGeneralContainer.dart';

class AdministrativeGeneral extends StatefulWidget {
  const AdministrativeGeneral({super.key});

  @override
  State<AdministrativeGeneral> createState() => _AdministrativeGeneralState();
}

class _AdministrativeGeneralState extends State<AdministrativeGeneral> with TickerProviderStateMixin{
  AdministrativeGeneralController administrativeGeneralController =
      Get.put(AdministrativeGeneralController());
  TabController? tabController;

  @override
  void initState() {
    super.initState();
    tabController = TabController(length: 3, vsync: this);
    administrativeGeneralController.fetchData();
  }

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(

      backgroundColor: AppColors.backGroundColor,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
    DefaultTabController(
    length: 3, // Updated length to 5 to include CDF
    child: Row(
    children: [
    Container(
    padding: EdgeInsets.only(top: 20),
    color: AppColors.backGroundColor,
    child: TabBar(
    tabAlignment: TabAlignment.start,
    overlayColor: MaterialStateProperty.all(Colors.transparent),
    automaticIndicatorColorAdjustment: true,
    dividerColor: AppColors.backGroundColor,
    unselectedLabelColor: AppColors.unSelectedtabsColor,
    labelColor: AppColors.whiteColor,
    labelPadding: EdgeInsets.only(left: 15),
    isScrollable: true,
    physics: BouncingScrollPhysics(),

    indicator: BoxDecoration(
    borderRadius: BorderRadius.circular(32),
    border: Border.all(color: AppColors.primaryColor),
    ),
    controller: tabController,
    tabs: [
    _buildTab('Faculty Members'), // New tab for CDF
    _buildTab('QEC Members'),
    _buildTab('QEC Convenors'),
    ]
    ),
    ),
        ],
      ),
      ),
          Flexible(
            child: TabBarView(
              controller: tabController,
              children: [
                MembersData(MemberType: "facultymember"), // Screen for CDF
                MembersData(MemberType: "qecmemberconsole"), // Screen for Assignments
                MembersData(MemberType: "qecconver"), // Screen for Quizzes
                // Screen for Final
              ]
              ,
            ),
          ),
   ] ));
}
  Widget _buildTab(String label) {
    return Container(
      height: 35,
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(35)),
      child: Tab(
        child: Center(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 15.0),
            child: Text(label, style: CustomTextStyles.l24_black),
          ),
        ),
      ),
    );
  }
  /* Container(
  color: AppColors.lightBlue,
  padding: EdgeInsets.only(left: 20, right: 20),
  child: Column(
  crossAxisAlignment: CrossAxisAlignment.start,
  children: [
  Padding(
  padding: const EdgeInsets.only(top: 18, right: 30),
  child: Row(
  crossAxisAlignment: CrossAxisAlignment.end,
  mainAxisAlignment: MainAxisAlignment.end,
  children: [
  CustomButton(
  height: height * 0.04,
  width: width * 0.05,
  text: 'Save',
  onPressed: () {},
  color: AppColors.primaryColor,
  textStyle: CustomTextStyles.l26_white,
  borderRadius: 40,
  ),
  ],
  ),
  ),
  SizedBox(height: height * 0.02),
  Expanded(
  child: ListView.builder(
  padding: EdgeInsets.only(bottom: height * 0.014),
  itemCount: administrativeGeneralController
      .administrationGeneralModel.length,
  itemBuilder: (context, index) {
  return Padding(
  padding: EdgeInsets.only(bottom: height * 0.014),
  child: AdministrativeGeneralContainer(
  height: height,
  width: width,
  administrationGeneralModel: administrativeGeneralController
      .administrationGeneralModel?.value[index],
  ),
  );
  },
  ),
  )
  ],
  ),
  );
}
*/}