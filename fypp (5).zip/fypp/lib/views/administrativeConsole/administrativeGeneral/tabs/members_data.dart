import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fypp/utils/appColors.dart';
import 'package:fypp/utils/constants.dart';

import '../../../../assetsPath/assetsPath.dart';


class MembersData extends StatefulWidget {
  final String MemberType;
  const MembersData({super.key, required this.MemberType});

  @override
  State<MembersData> createState() => _MembersDataState();
}

class _MembersDataState extends State<MembersData> {
  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.sizeOf(context).height;
    final width = MediaQuery.sizeOf(context).width;
    return Scaffold(
      backgroundColor: AppColors.backGroundColor,
      body: StreamBuilder(stream: FirebaseFirestore.instance.collection("users").snapshots(), builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(
            child: CircularProgressIndicator(),
          );
        }
        if (snapshot.hasError) {
          return Center(
            child: Text('Error: ${snapshot.error}'),
          );
        }
        var users = snapshot.data!.docs.where((element) => element['userType'].toString().contains(widget.MemberType)).toList();
        return users.isNotEmpty ? ListView.builder(itemCount: users.length, itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.only(top:  20.0),
            child: Container(
                padding: EdgeInsets.only(top: 10, left: 14, right: 10, bottom: 10),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(35),
                    border: Border.all(color: AppColors.primaryColor, width: 1)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(users[index]['username']),
                    Text(users[index]['email']),
                    Text(Constants.getAbb(users[index]['userType'])),
                    InkWell(
                      onTap: (){
                        showDialog(context: context, builder: (context) => AlertDialog(
                          title: Text('Are you sure you want to delete this member?'),
                          actions: [
                            TextButton(onPressed: () => Navigator.pop(context), child: Text('No')),
                            TextButton(onPressed: ()async{

                              await FirebaseFirestore.instance.collection('users').doc(users[index].id).delete();
                              Navigator.pop(context);
                            }, child: Text('Yes')),
                          ],
                        ),);

                      },
                      child: Image.asset(
                        '${Assets.imagesPath}${Assets.crossIcon}',
                        height: height * 0.03,
                        width: width * 0.03,
                      ),
                    )

                  ],
                )
            ),
          );
      },) : Center(child: Text('No Members Found'),);
        },),
    );
  }
}
