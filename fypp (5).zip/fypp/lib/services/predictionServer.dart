import 'dart:convert';
import 'dart:typed_data';
import 'dart:io' show Platform;
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:http/http.dart' as http;

class PredictionService {
  final String baseURl;

  PredictionService(this.baseURl);

  Future<Map<String, dynamic>> predict({
    Uint8List? fileData,
    String? fileName,
  }) async {
    var request = http.MultipartRequest('POST', Uri.parse('$baseURl/classify'));

      // For web, use fileData
      if (fileData == null || fileName == null) {
        throw Exception("fileData and fileName are required for web platforms");
      }
      request.files.add(http.MultipartFile.fromBytes(
        'file',
        fileData,
        filename: fileName,
      ));


    var streamedResponse = await request.send();
    var response = await http.Response.fromStream(streamedResponse);

    if (response.statusCode >= 200 && response.statusCode < 300) {
      Map<String, dynamic> responseData = json.decode(response.body);
      return responseData;
    } else {
      EasyLoading.showError('Invaild Image');
      EasyLoading.dismiss();
      throw Exception('Failed to predict: ${response.statusCode}');
    }
  }
}
