import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:fypp/models/user_model/user_modal.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../controllers/user_controller.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<User?> signUpWithEmail(String email, String password, String username, String userType) async {
    try {
      UserCredential userCredential =
          await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      await FirebaseFirestore.instance.collection('users').doc(userCredential.user!.uid).set({
        'email': email,
        'username': username,
        'userType': userType,
        'uid': userCredential.user!.uid,
      });

      var userController = Get.find<UserController>();
      userController.setUserModal(UserModal.fromJson({
        'email': email,
        'username': username,
        'userType': userType,
        'uid': userCredential.user!.uid,
      }));
      print("User Type: $userType");
      return userCredential.user;
    } catch (e) {
      EasyLoading.showError('Something went wrong');
      EasyLoading.dismiss();
      print('Sign Up Error: $e');
      return null;
    }
  }

  Future<String?> signInWithEmail(String email, String password) async {
    try {
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      var userDoc = await FirebaseFirestore.instance.collection('users').doc(userCredential.user!.uid).get();

      var userController = Get.find<UserController>();
      userController.setUserModal(UserModal.fromJson({
        'email': userDoc['email'],
        'username': userDoc['username'],
        'userType': userDoc['userType'],
        'uid': userCredential.user!.uid,
      }));
      var prefs = await SharedPreferences.getInstance();
      prefs.setString('uid', userCredential.user!.uid);
      prefs.setString("role", userDoc['userType']);
      print("User Type: ${userDoc['userType']}");
      return userDoc['userType'];
    } catch (e) {
      EasyLoading.showError('Invalid Email or Password');
      EasyLoading.dismiss();
      print('Sign In Error: $e');
      return null;
    }
  }

  Future<void> signOut() async {
    await _auth.signOut();
  }

  Stream<User?> get userChanges => _auth.authStateChanges();
}
