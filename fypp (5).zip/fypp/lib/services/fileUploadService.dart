import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart'; // Import Firebase Storage

class FileUploadService {
  /// Picks a file using File Picker.
  Future<PlatformFile?> pickFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles();
    if (result != null) {
      return result.files.single; // Return the selected file as PlatformFile
    }
    return null;
  }

  /// Uploads a file to Firebase Storage.
  Future<String?> uploadFileToFirebaseStorage(
      Uint8List fileBytes, String fileName) async {
    try {
      // Create a reference to the Firebase Storage location
      final storageRef =
          FirebaseStorage.instance.ref().child('uploads/$fileName');

      // Upload the file to Firebase Storage
      final uploadTask = storageRef.putData(fileBytes);

      // Wait for the upload to complete
      await uploadTask.whenComplete(() => null);

      // Get the download URL for the uploaded file
      final downloadUrl = await storageRef.getDownloadURL();
      print('File uploaded successfully: $downloadUrl');
      return downloadUrl;
    } catch (e) {
      print('Error occurred during file upload: $e');
      return null;
    }
  }
}
