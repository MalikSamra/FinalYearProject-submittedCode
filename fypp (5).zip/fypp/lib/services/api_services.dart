import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ApiService {
  final String baseUrl =
      'http://localhost:3000'; // Replace with your server URL if different

  Future<http.Response> get(String endpoint) async {
    final response = await http.get(Uri.parse('$baseUrl/$endpoint'));
    return _handleResponse(response);
  }

  Future<http.Response> post(String endpoint, Map<String, dynamic> data) async {
    final response = await http.post(
      Uri.parse('$baseUrl/$endpoint'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode(data),
    );
    return _handleResponse(response);
  }

  Future<http.Response> put(String endpoint, Map<String, dynamic> data) async {
    final response = await http.put(
      Uri.parse('$baseUrl/$endpoint'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode(data),
    );
    return _handleResponse(response);
  }

  Future<http.Response> delete(String endpoint) async {
    final response = await http.delete(Uri.parse('$baseUrl/$endpoint'));
    return _handleResponse(response);
  }

  Future<List<Map<String, dynamic>>> uploadFile(String filePath) async {
    var request = http.MultipartRequest('POST', Uri.parse('$baseUrl/upload'));
    request.files.add(await http.MultipartFile.fromPath('file', filePath));

    var streamedResponse = await request.send();
    var response = await http.Response.fromStream(streamedResponse);

    if (response.statusCode >= 200 && response.statusCode < 300) {
      List<Map<String, dynamic>> responseData =
          List<Map<String, dynamic>>.from(json.decode(response.body));
      return responseData;
    } else {
      throw Exception('Failed to upload file: ${response.statusCode}');
    }
  }

  http.Response _handleResponse(http.Response response) {
    if (response.statusCode >= 200 && response.statusCode < 300) {
      return response;
    } else {
      throw Exception('Failed to load data: ${response.statusCode}');
    }
  }

  static String returnFileUrl(AsyncSnapshot<QuerySnapshot<Map<String, dynamic>>> snapshot, String condition) {
    if(snapshot.hasData){
      if(snapshot.data!.docs.isNotEmpty) {
        return snapshot.data!.docs.where((element) => element['title'] == condition).first['url'];
      }else{
        return '';
      }
    }else{
      return '';
    }

  }

  static String baseURl = 'https://3458-35-197-52-130.ngrok-free.app';


}
