import 'package:supabase_flutter/supabase_flutter.dart';
import 'dart:io';

const bucketName = 'fyp_bucket';
class SupabaseService{
  Future<void> uploadFile(File file, String path) async {
    try {
      final response = await Supabase.instance.client.storage.from(bucketName).upload(
        path,
        file,
      );
      if (response.isEmpty) {
        throw response;
      }
      print('File uploaded successfully: ${response}');
    } catch (e) {
      print('Error uploading file: $e');
    }
  }

  Future<void> downloadFile(String path) async {
    try {
      final fileUrl = Supabase.instance.client.storage.from(bucketName).getPublicUrl(path);
      print('File URL: $fileUrl');
    } catch (e) {
      print('Error downloading file: $e');
    }
  }
}