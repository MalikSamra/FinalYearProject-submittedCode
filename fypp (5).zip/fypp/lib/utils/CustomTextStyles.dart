import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fypp/utils/fonts.dart';

class CustomTextStyles {
  static var l28_400_white = TextStyle(
    fontSize: 48.sp,
    fontFamily: CustomFonts.interMediam,
    color: Colors.white,
  );
  static var appBarTitleTextStyle = TextStyle(
    fontSize: 24.sp,
    fontFamily: CustomFonts.interMediam,
    color: Colors.white,
  );
  static var l24_white = TextStyle(
    fontSize: 20.sp,
    fontFamily: CustomFonts.interMediam,
    color: Colors.white,
  );
  static var l26_white = TextStyle(
    fontSize: 26.sp,
    fontFamily: CustomFonts.interMediam,
    color: Colors.white,
  );
  static var l36_white = TextStyle(
    fontSize: 36.sp,
    fontFamily: CustomFonts.interMediam,
    color: Colors.white,
  );
  static var l32_black = TextStyle(
    fontSize: 32.sp,
    fontFamily: CustomFonts.interMediam,
    color: Colors.black,
  );
  static var l16_blac = TextStyle(
    fontSize: 16.sp,
    color: Colors.black,
  );
  static var l24_black = TextStyle(
    fontSize: 24.sp,
    color: Colors.black,
  );

  static var l17_white = TextStyle(
    fontSize: 17.sp,
    color: Colors.white,
  );
}
