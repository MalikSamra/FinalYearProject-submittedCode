class CustomFonts {
  static const String interMediam = 'Inter-Medium';
}
