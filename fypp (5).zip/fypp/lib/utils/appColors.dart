// ignore_for_file: non_constant_identifier_names

import 'package:flutter/material.dart';

class AppColors {
  static const Color primaryColor = Color(0xFF5295D2);
  static const Color blackColor = Colors.black;
  static const Color e7e7e7 = Color(0xffE7E7E7);
  static const Color backGroundColor = Color(0xFFf0f4f8);
  static const Color whiteColor = Colors.white;
  static Color borderColor = Color(0xffDADAE4);
  static Color greyColor = Colors.grey;
  static Color unSelectedtabsColor = Color(0xff8A8A8A);
  static Color lightBlue = Color(0xffF0F4F8);
  static Color d9d9d9 = Color(0xffD9D9D9);
}
