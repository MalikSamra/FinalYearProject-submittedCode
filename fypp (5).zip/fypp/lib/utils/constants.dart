class Constants {
  static const EXPO_PUBLIC_SUPABASE_URL = "https://tvuzlhkbfpwuoomefmmo.supabase.co";
  static const EXPO_PUBLIC_SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR2dXpsaGtiZnB3dW9vbWVmbW1vIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzE5NTEyNzcsImV4cCI6MjA0NzUyNzI3N30.V-ZTaCq7EGKEQ7EcAu7G2BdBRFmc8t-xIIu6PsLV2FQ";
  static String getConsoleName(String text) {
    switch (text) {
      case 'QEC Convenor':
        return 'qecconver';
      case 'QEC Member':
        return 'qecmemberconsole';
      case 'Faculty Member':
        return 'facultymember';
      default:
        return '';
    }
  }
  static String getAbb(String text) {
    switch (text) {
      case 'administrative':
        return 'Administrative';
      case 'qecconver':
        return 'QEC Convenor';
      case 'qecmemberconsole':
        return 'QEC Member';
      case 'facultymember':
        return 'Faculty Member';
      default:
        return '';
    }
  }
}