import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return webOptions;
    }
    throw UnsupportedError(
        'DefaultFirebaseOptions are not supported on this platform.');
  }

  static const FirebaseOptions webOptions = FirebaseOptions(
    apiKey: 'AIzaSyArwlvDUM1UYOqur0nZdDgGx7K8QjgBnSA',
    authDomain: 'myfyp-52643.firebaseapp.com',
    projectId: 'myfyp-52643',
    storageBucket: 'myfyp-52643.appspot.com',
    messagingSenderId: '1037321854654',
    appId: '1:1037321854654:web:af74b958a76311302448ef',
    measurementId: 'G-60J5ETRTRY',
  );

// Add FirebaseOptions for other platforms (iOS, Android, etc.) if needed
}
